// Mock data store for the NetworkMinder app
// This simulates a database and provides data persistence during the app session

import { create } from "zustand"
import { persist } from "zustand/middleware"

// Types
export type Contact = {
  id: number
  name: string
  handle: string
  notes: string
  image: string
  reminder: boolean
  reminderDate: string | null
  email?: string
  phone?: string
  lastContact?: string
  socialProfiles?: {
    linkedin?: string
    facebook?: string
    twitter?: string
    instagram?: string
  }
}

export type Message = {
  id: number
  contactId: number
  sender: "user" | "contact"
  text: string
  time: string
  read: boolean
}

export type Notification = {
  id: number
  type: "instagram_tag" | "reminder" | "birthday" | "job_change" | "achievement"
  user: {
    id: number
    name: string
    handle: string
    image: string
  }
  content: string
  postImage?: string
  time: string
  read: boolean
}

export type Event = {
  id: number
  title: string
  date: string
  time?: string
  location: string
  attendees: number
  contacts: number
  image: string
  category: string
  description?: string
}

export type Achievement = {
  id: number
  name: string
  description: string
  icon: string
  progress: number
  completed: boolean
  date?: string
  reward: string
  category: string
  target?: number
  current?: number
}

// Initial data
const initialContacts: Contact[] = [
  {
    id: 1,
    name: "Alex Johnson",
    handle: "@alexjohnson",
    notes:
      "Met at TechConf 2023, interested in AI and machine learning. Works at InnovateTech as a Senior Developer. Mentioned potential collaboration on the new project.",
    image: "/placeholder.svg?height=200&width=200",
    reminder: true,
    reminderDate: "2025-03-20",
    lastContact: "2025-03-01",
    email: "alex.johnson@example.com",
    phone: "+1 (555) 123-4567",
    socialProfiles: {
      linkedin: "linkedin.com/in/alexjohnson",
      facebook: "facebook.com/alexjohnson",
    },
  },
  {
    id: 2,
    name: "Sam Rivera",
    handle: "@samrivera",
    notes:
      "Marketing specialist, potential collaboration on content strategy. Discussed partnership opportunities for Q2.",
    image: "/placeholder.svg?height=200&width=200",
    reminder: false,
    reminderDate: null,
    lastContact: "2025-02-15",
    email: "sam.rivera@example.com",
    phone: "+1 (555) 234-5678",
    socialProfiles: {
      linkedin: "linkedin.com/in/samrivera",
      twitter: "twitter.com/samrivera",
    },
  },
  {
    id: 3,
    name: "Jordan Lee",
    handle: "@jordanlee",
    notes:
      "UX Designer at DesignHub, coffee chat scheduled for next week. Interested in collaborating on the app redesign.",
    image: "/placeholder.svg?height=200&width=200",
    reminder: true,
    reminderDate: "2025-03-18",
    lastContact: "2025-02-28",
    email: "jordan.lee@example.com",
    phone: "+1 (555) 345-6789",
    socialProfiles: {
      linkedin: "linkedin.com/in/jordanlee",
      instagram: "instagram.com/jordanlee.design",
    },
  },
  {
    id: 4,
    name: "Taylor Wilson",
    handle: "@taylorwilson",
    notes: "Product Manager at InnoTech. Discussed potential partnership for upcoming product launch.",
    image: "/placeholder.svg?height=200&width=200",
    reminder: false,
    reminderDate: null,
    lastContact: "2025-02-10",
    email: "taylor.wilson@example.com",
    phone: "+1 (555) 456-7890",
    socialProfiles: {
      linkedin: "linkedin.com/in/taylorwilson",
      facebook: "facebook.com/taylorwilson",
    },
  },
  {
    id: 5,
    name: "Casey Morgan",
    handle: "@caseymorgan",
    notes: "Startup founder, looking for investors. Introduced by Sam at the networking event last month.",
    image: "/placeholder.svg?height=200&width=200",
    reminder: true,
    reminderDate: "2025-03-25",
    lastContact: "2025-03-05",
    email: "casey.morgan@example.com",
    phone: "+1 (555) 567-8901",
    socialProfiles: {
      linkedin: "linkedin.com/in/caseymorgan",
      twitter: "twitter.com/caseymorgan",
    },
  },
]

const initialMessages: Record<number, Message[]> = {
  1: [
    {
      id: 1,
      contactId: 1,
      sender: "contact",
      text: "Hey there! How's the project coming along?",
      time: "10:15 AM",
      read: true,
    },
    {
      id: 2,
      contactId: 1,
      sender: "user",
      text: "It's going well! Just finalizing some details.",
      time: "10:20 AM",
      read: true,
    },
    {
      id: 3,
      contactId: 1,
      sender: "contact",
      text: "Great to hear! Let's catch up soon!",
      time: "10:30 AM",
      read: true,
    },
  ],
  2: [
    {
      id: 4,
      contactId: 2,
      sender: "contact",
      text: "Thanks for connecting me with your team!",
      time: "Yesterday",
      read: true,
    },
    {
      id: 5,
      contactId: 2,
      sender: "user",
      text: "No problem at all, hope it works out!",
      time: "Yesterday",
      read: true,
    },
    { id: 6, contactId: 2, sender: "contact", text: "Thanks for the introduction", time: "Yesterday", read: true },
  ],
  3: [
    {
      id: 7,
      contactId: 3,
      sender: "user",
      text: "Hi Jordan, are we still on for coffee next week?",
      time: "2 days ago",
      read: true,
    },
    {
      id: 8,
      contactId: 3,
      sender: "contact",
      text: "Yes, definitely! Tuesday at 2pm works for me.",
      time: "2 days ago",
      read: true,
    },
    { id: 9, contactId: 3, sender: "contact", text: "Looking forward to our meeting", time: "2 days ago", read: true },
  ],
}

const initialNotifications: Notification[] = [
  {
    id: 1,
    type: "instagram_tag",
    user: {
      id: 3,
      name: "Jordan Lee",
      handle: "@jordanlee",
      image: "/placeholder.svg?height=40&width=40",
    },
    content: "tagged you in a post",
    postImage: "/placeholder.svg?height=100&width=100",
    time: "10 minutes ago",
    read: false,
  },
  {
    id: 2,
    type: "job_change",
    user: {
      id: 1,
      name: "Alex Johnson",
      handle: "@alexjohnson",
      image: "/placeholder.svg?height=40&width=40",
    },
    content: "started a new position at InnovateTech",
    time: "2 hours ago",
    read: false,
  },
  {
    id: 3,
    type: "reminder",
    user: {
      id: 2,
      name: "Sam Rivera",
      handle: "@samrivera",
      image: "/placeholder.svg?height=40&width=40",
    },
    content: "Follow-up reminder",
    time: "Yesterday",
    read: true,
  },
]

const initialEvents: Event[] = [
  {
    id: 1,
    title: "Tech Innovators Meetup",
    date: "Mar 25, 2025",
    time: "6:00 PM - 9:00 PM",
    location: "Downtown Convention Center",
    attendees: 120,
    contacts: 5,
    image: "/placeholder.svg?height=100&width=200",
    category: "technology",
    description: "Connect with tech professionals and innovators in your area.",
  },
  {
    id: 2,
    title: "Women in Business Conference",
    date: "Apr 10, 2025",
    time: "9:00 AM - 5:00 PM",
    location: "Grand Hotel & Conference Center",
    attendees: 250,
    contacts: 0,
    image: "/placeholder.svg?height=100&width=200",
    category: "business",
    description: "Annual conference for women business leaders and entrepreneurs.",
  },
  {
    id: 3,
    title: "Startup Pitch Night",
    date: "Apr 18, 2025",
    time: "7:00 PM - 10:00 PM",
    location: "Innovation Hub",
    attendees: 85,
    contacts: 2,
    image: "/placeholder.svg?height=100&width=200",
    category: "startup",
    description: "Watch startups pitch their ideas and network with founders and investors.",
  },
]

const initialAchievements: Achievement[] = [
  {
    id: 1,
    name: "Network Builder",
    description: "Add 10 contacts to your network",
    icon: "Users",
    progress: 100,
    completed: true,
    date: "2025-03-01",
    reward: "Bronze Badge",
    category: "connections",
  },
  {
    id: 2,
    name: "Follow-up Master",
    description: "Complete 15 follow-ups on time",
    icon: "Calendar",
    progress: 100,
    completed: true,
    date: "2025-03-05",
    reward: "Silver Badge",
    category: "engagement",
  },
  {
    id: 3,
    name: "Conversation Starter",
    description: "Send 20 messages to your contacts",
    icon: "MessageCircle",
    progress: 80,
    completed: false,
    target: 20,
    current: 16,
    reward: "5 AI Credits",
    category: "engagement",
  },
]

// Create store
type AppState = {
  contacts: Contact[]
  messages: Record<number, Message[]>
  notifications: Notification[]
  events: Event[]
  achievements: Achievement[]
  user: {
    name: string
    email: string
    image: string
    level: number
    points: number
    socialConnected: {
      linkedin: boolean
      facebook: boolean
    }
  }
  // Actions
  addContact: (contact: Omit<Contact, "id">) => void
  updateContact: (id: number, contact: Partial<Contact>) => void
  deleteContact: (id: number) => void
  toggleReminder: (id: number) => void
  addMessage: (contactId: number, message: Omit<Message, "id">) => void
  markNotificationAsRead: (id: number) => void
  markAllNotificationsAsRead: () => void
  addNotification: (notification: Omit<Notification, "id">) => void
  connectSocial: (platform: "linkedin" | "facebook", connected: boolean) => void
}

export const useAppStore = create<AppState>()(
  persist(
    (set) => ({
      contacts: initialContacts,
      messages: initialMessages,
      notifications: initialNotifications,
      events: initialEvents,
      achievements: initialAchievements,
      user: {
        name: "Jamie Smith",
        email: "jamie.smith@example.com",
        image: "/placeholder.svg?height=200&width=200",
        level: 3,
        points: 580,
        socialConnected: {
          linkedin: false,
          facebook: false,
        },
      },
      // Actions
      addContact: (contact) =>
        set((state) => ({
          contacts: [...state.contacts, { ...contact, id: Math.max(0, ...state.contacts.map((c) => c.id)) + 1 }],
        })),
      updateContact: (id, updatedContact) =>
        set((state) => ({
          contacts: state.contacts.map((contact) => (contact.id === id ? { ...contact, ...updatedContact } : contact)),
        })),
      deleteContact: (id) =>
        set((state) => ({
          contacts: state.contacts.filter((contact) => contact.id !== id),
        })),
      toggleReminder: (id) =>
        set((state) => ({
          contacts: state.contacts.map((contact) =>
            contact.id === id
              ? {
                  ...contact,
                  reminder: !contact.reminder,
                  reminderDate: !contact.reminder
                    ? new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString().split("T")[0]
                    : null,
                }
              : contact,
          ),
        })),
      addMessage: (contactId, message) =>
        set((state) => {
          const contactMessages = state.messages[contactId] || []
          const newMessage = {
            ...message,
            id:
              Math.max(
                0,
                ...Object.values(state.messages)
                  .flat()
                  .map((m) => m.id),
              ) + 1,
            contactId,
          }

          return {
            messages: {
              ...state.messages,
              [contactId]: [...contactMessages, newMessage],
            },
          }
        }),
      markNotificationAsRead: (id) =>
        set((state) => ({
          notifications: state.notifications.map((notification) =>
            notification.id === id ? { ...notification, read: true } : notification,
          ),
        })),
      markAllNotificationsAsRead: () =>
        set((state) => ({
          notifications: state.notifications.map((notification) => ({ ...notification, read: true })),
        })),
      addNotification: (notification) =>
        set((state) => ({
          notifications: [
            {
              ...notification,
              id: Math.max(0, ...state.notifications.map((n) => n.id)) + 1,
              read: false,
              time: "Just now",
            },
            ...state.notifications,
          ],
        })),
      connectSocial: (platform, connected) =>
        set((state) => ({
          user: {
            ...state.user,
            socialConnected: {
              ...state.user.socialConnected,
              [platform]: connected,
            },
          },
        })),
    }),
    {
      name: "networkminder-storage",
    },
  ),
)

