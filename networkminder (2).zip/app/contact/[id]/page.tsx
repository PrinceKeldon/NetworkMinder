"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import Image from "next/image"
import { Calendar, Edit, Trash2, MessageCircle, Linkedin, Facebook, Twitter, Instagram } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { useToast } from "@/hooks/use-toast"
import { SocialProfileCard } from "@/components/social-profile-card"
import { SocialEventNotification } from "@/components/social-event-notification"
import { useAppStore } from "@/lib/data"

export default function ContactDetail({ params }: { params: { id: string } }) {
  const router = useRouter()
  const { toast } = useToast()
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false)
  const [showSocialNotification, setShowSocialNotification] = useState(false)
  const [notificationType, setNotificationType] = useState<"birthday" | "job" | "anniversary" | "achievement">("job")

  const contacts = useAppStore((state) => state.contacts)
  const deleteContact = useAppStore((state) => state.deleteContact)
  const toggleReminder = useAppStore((state) => state.toggleReminder)

  const contactId = Number.parseInt(params.id)
  const contactData = contacts.find((c) => c.id === contactId)

  // Redirect if contact not found
  useEffect(() => {
    if (!contactData) {
      router.push("/")
    }
  }, [contactData, router])

  // Simulate receiving a social notification
  useEffect(() => {
    const timer = setTimeout(() => {
      setNotificationType("job")
      setShowSocialNotification(true)
    }, 5000)

    return () => clearTimeout(timer)
  }, [])

  const handleDelete = () => {
    if (contactData) {
      deleteContact(contactId)
      toast({
        title: "Contact deleted",
        description: `${contactData.name} has been removed from your contacts`,
      })
      setIsDeleteDialogOpen(false)
      router.push("/")
    }
  }

  const handleSetReminder = () => {
    if (contactData) {
      toggleReminder(contactId)
      toast({
        title: contactData.reminder ? "Reminder updated" : "Reminder set",
        description: `You'll be reminded to follow up with ${contactData.name} on ${new Date(contactData.reminderDate || "").toLocaleDateString()}`,
      })
    }
  }

  const handleStartChat = () => {
    router.push(`/chat?contact=${params.id}`)
  }

  if (!contactData) {
    return null // Will redirect in useEffect
  }

  return (
    <div className="container py-6 max-w-md mx-auto">
      <Card className="overflow-hidden mb-6">
        <div className="p-6">
          <div className="flex flex-col items-center mb-6">
            <div className="relative h-40 w-40 rounded-full overflow-hidden mb-4 border-4 border-highlight">
              <Image
                src={contactData.image || "/placeholder.svg"}
                alt={contactData.name}
                fill
                className="object-cover"
              />
            </div>
            <h1 className="text-2xl font-bold">{contactData.name}</h1>
            <p className="text-muted-foreground">{contactData.handle}</p>

            <div className="flex space-x-2 mt-2">
              {contactData.socialProfiles?.linkedin && (
                <Badge variant="outline" className="bg-[#0077B5]/10 border-[#0077B5]/20 text-[#0077B5]">
                  <Linkedin className="h-3 w-3 mr-1" />
                  LinkedIn
                </Badge>
              )}
              {contactData.socialProfiles?.facebook && (
                <Badge variant="outline" className="bg-[#1877F2]/10 border-[#1877F2]/20 text-[#1877F2]">
                  <Facebook className="h-3 w-3 mr-1" />
                  Facebook
                </Badge>
              )}
              {contactData.socialProfiles?.twitter && (
                <Badge variant="outline" className="bg-[#1DA1F2]/10 border-[#1DA1F2]/20 text-[#1DA1F2]">
                  <Twitter className="h-3 w-3 mr-1" />
                  Twitter
                </Badge>
              )}
              {contactData.socialProfiles?.instagram && (
                <Badge variant="outline" className="bg-[#E1306C]/10 border-[#E1306C]/20 text-[#E1306C]">
                  <Instagram className="h-3 w-3 mr-1" />
                  Instagram
                </Badge>
              )}
            </div>
          </div>

          <div className="space-y-6">
            {contactData.email && (
              <div>
                <h2 className="text-sm font-medium text-muted-foreground mb-1">Email</h2>
                <p>{contactData.email}</p>
              </div>
            )}

            {contactData.phone && (
              <div>
                <h2 className="text-sm font-medium text-muted-foreground mb-1">Phone</h2>
                <p>{contactData.phone}</p>
              </div>
            )}

            <div>
              <h2 className="text-sm font-medium text-muted-foreground mb-1">Notes</h2>
              <p className="whitespace-pre-line">{contactData.notes}</p>
            </div>

            <div>
              <h2 className="text-sm font-medium text-muted-foreground mb-1">Last Contact</h2>
              <p>{contactData.lastContact}</p>
            </div>

            {contactData.reminder && (
              <div>
                <h2 className="text-sm font-medium text-muted-foreground mb-1">Follow-up Reminder</h2>
                <Badge variant="outline" className="flex items-center">
                  <Calendar className="mr-1 h-3 w-3" />
                  {new Date(contactData.reminderDate || "").toLocaleDateString()}
                </Badge>
              </div>
            )}
          </div>

          <div className="mt-8 space-y-3">
            <Button className="w-full bg-primary hover:bg-primary/90" onClick={handleStartChat}>
              <MessageCircle className="mr-2 h-4 w-4" />
              Send Message
            </Button>

            <Button
              variant="outline"
              className="w-full border-highlight text-foreground hover:bg-highlight hover:text-highlight-foreground"
              onClick={handleSetReminder}
            >
              <Calendar className="mr-2 h-4 w-4" />
              {contactData.reminder ? "Update Reminder" : "Set Reminder"}
            </Button>

            <div className="flex space-x-3">
              <Button variant="outline" className="flex-1" onClick={() => router.push(`/edit-contact/${params.id}`)}>
                <Edit className="mr-2 h-4 w-4" />
                Edit
              </Button>

              <Dialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
                <DialogTrigger asChild>
                  <Button variant="destructive" className="flex-1">
                    <Trash2 className="mr-2 h-4 w-4" />
                    Delete
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Delete Contact</DialogTitle>
                    <DialogDescription>
                      Are you sure you want to delete {contactData.name}? This action cannot be undone.
                    </DialogDescription>
                  </DialogHeader>
                  <DialogFooter>
                    <Button variant="outline" onClick={() => setIsDeleteDialogOpen(false)}>
                      Cancel
                    </Button>
                    <Button variant="destructive" onClick={handleDelete}>
                      Delete
                    </Button>
                  </DialogFooter>
                </DialogContent>
              </Dialog>
            </div>
          </div>
        </div>
      </Card>

      <SocialProfileCard contact={{ id: contactData.id, name: contactData.name }} />

      {showSocialNotification && (
        <SocialEventNotification type={notificationType} onClose={() => setShowSocialNotification(false)} />
      )}
    </div>
  )
}

