"use client"

import type React from "react"
import { useState, useRef } from "react"
import { useRouter } from "next/navigation"
import Image from "next/image"
import { Camera, Upload } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Card } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { useToast } from "@/hooks/use-toast"
import { useAppStore } from "@/lib/data"

export default function AddContact() {
  const router = useRouter()
  const { toast } = useToast()
  const fileInputRef = useRef<HTMLInputElement>(null)
  const [activeTab, setActiveTab] = useState("manual")
  const [formData, setFormData] = useState({
    name: "",
    handle: "",
    notes: "",
    image: "/placeholder.svg?height=200&width=200",
    email: "",
    phone: "",
  })
  const [instagramHandle, setInstagramHandle] = useState("")
  const [isLoading, setIsLoading] = useState(false)

  const addContact = useAppStore((state) => state.addContact)

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) {
      const imageUrl = URL.createObjectURL(file)
      setFormData((prev) => ({ ...prev, image: imageUrl }))
    }
  }

  const handleTakePhoto = () => {
    // In a real app, this would access the camera
    // For this demo, we'll just trigger the file input
    if (fileInputRef.current) {
      fileInputRef.current.click()
    }
  }

  const handleImportFromInstagram = async () => {
    if (!instagramHandle) {
      toast({
        title: "Error",
        description: "Please enter an Instagram handle",
        variant: "destructive",
      })
      return
    }

    setIsLoading(true)

    // Simulate API call to fetch Instagram profile
    setTimeout(() => {
      // Mock data for demo purposes
      const mockData = {
        name: instagramHandle
          .replace("@", "")
          .split("_")
          .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
          .join(" "),
        handle: instagramHandle,
        image: "/placeholder.svg?height=200&width=200",
        notes: `Imported from Instagram: ${instagramHandle}`,
        socialProfiles: {
          instagram: `instagram.com/${instagramHandle.replace("@", "")}`,
        },
      }

      setFormData({
        ...formData,
        name: mockData.name,
        handle: mockData.handle,
        notes: mockData.notes,
        image: mockData.image,
      })
      setActiveTab("manual")
      setIsLoading(false)

      toast({
        title: "Profile imported",
        description: `Successfully imported ${instagramHandle}`,
      })
    }, 1500)
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    if (!formData.name) {
      toast({
        title: "Error",
        description: "Please enter a name for your contact",
        variant: "destructive",
      })
      return
    }

    // Add the contact to our store
    addContact({
      ...formData,
      reminder: false,
      reminderDate: null,
      socialProfiles: formData.handle.includes("@")
        ? {
            instagram: `instagram.com/${formData.handle.replace("@", "")}`,
          }
        : undefined,
    })

    toast({
      title: "Contact added",
      description: `${formData.name} has been added to your contacts`,
    })

    // Navigate back to the contacts list
    router.push("/")
  }

  return (
    <div className="container py-6 max-w-md mx-auto">
      <h1 className="text-2xl font-bold mb-6">Add New Contact</h1>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="manual">Manual Entry</TabsTrigger>
          <TabsTrigger value="instagram">Import from Instagram</TabsTrigger>
        </TabsList>

        <TabsContent value="instagram" className="mt-6">
          <Card className="p-4">
            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="instagram-handle">Instagram Handle</Label>
                <div className="flex space-x-2">
                  <Input
                    id="instagram-handle"
                    placeholder="@username"
                    value={instagramHandle}
                    onChange={(e) => setInstagramHandle(e.target.value)}
                  />
                  <Button onClick={handleImportFromInstagram} disabled={isLoading}>
                    {isLoading ? "Importing..." : "Import"}
                  </Button>
                </div>
              </div>
              <div className="text-sm text-muted-foreground">
                Enter an Instagram handle to import profile information
              </div>
            </div>
          </Card>
        </TabsContent>

        <TabsContent value="manual" className="mt-6">
          <form onSubmit={handleSubmit}>
            <div className="space-y-6">
              <div className="flex justify-center">
                <div className="relative h-40 w-40 rounded-full overflow-hidden border-2 border-highlight">
                  <Image src={formData.image || "/placeholder.svg"} alt="Contact photo" fill className="object-cover" />
                </div>
              </div>

              <div className="flex justify-center space-x-4">
                <Button
                  type="button"
                  variant="outline"
                  onClick={handleTakePhoto}
                  className="border-primary text-primary hover:bg-primary hover:text-primary-foreground"
                >
                  <Camera className="mr-2 h-4 w-4" />
                  Take Photo
                </Button>
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => fileInputRef.current?.click()}
                  className="border-primary text-primary hover:bg-primary hover:text-primary-foreground"
                >
                  <Upload className="mr-2 h-4 w-4" />
                  Upload
                </Button>
                <input type="file" ref={fileInputRef} className="hidden" accept="image/*" onChange={handleFileChange} />
              </div>

              <div className="space-y-2">
                <Label htmlFor="name">Name</Label>
                <Input
                  id="name"
                  name="name"
                  value={formData.name}
                  onChange={handleInputChange}
                  placeholder="Enter name"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="handle">Handle/Username</Label>
                <Input
                  id="handle"
                  name="handle"
                  value={formData.handle}
                  onChange={handleInputChange}
                  placeholder="@username"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="email">Email</Label>
                <Input
                  id="email"
                  name="email"
                  type="email"
                  value={formData.email}
                  onChange={handleInputChange}
                  placeholder="email@example.com"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="phone">Phone</Label>
                <Input
                  id="phone"
                  name="phone"
                  value={formData.phone}
                  onChange={handleInputChange}
                  placeholder="Phone number"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="notes">Notes</Label>
                <Textarea
                  id="notes"
                  name="notes"
                  value={formData.notes}
                  onChange={handleInputChange}
                  placeholder="Add notes about this contact"
                  rows={4}
                />
              </div>

              <Button type="submit" className="w-full bg-primary hover:bg-primary/90">
                Save Contact
              </Button>
            </div>
          </form>
        </TabsContent>
      </Tabs>
    </div>
  )
}

