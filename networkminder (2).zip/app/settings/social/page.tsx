"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, Share2 } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { SocialConnectPanel } from "@/components/social-connect-panel"
import { SocialShareDialog } from "@/components/social-share-dialog"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Switch } from "@/components/ui/switch"

export default function SocialSettingsPage() {
  const [activeTab, setActiveTab] = useState("accounts")
  const [notificationSettings, setNotificationSettings] = useState({
    birthdays: true,
    jobChanges: true,
    workAnniversaries: true,
    achievements: true,
    newConnections: false,
    messages: true,
  })

  const toggleNotification = (setting: keyof typeof notificationSettings) => {
    setNotificationSettings((prev) => ({
      ...prev,
      [setting]: !prev[setting],
    }))
  }

  return (
    <div className="min-h-screen bg-background">
      <header className="sticky top-0 z-10 border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex h-14 items-center">
          <Link href="/">
            <Button variant="ghost">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Back
            </Button>
          </Link>
          <div className="ml-4">
            <h1 className="font-semibold">Social Media Settings</h1>
          </div>
          <div className="ml-auto">
            <SocialShareDialog
              trigger={
                <Button size="sm">
                  <Share2 className="h-4 w-4 mr-2" />
                  Share
                </Button>
              }
            />
          </div>
        </div>
      </header>

      <main className="container py-6">
        <div className="mb-6">
          <h1 className="text-2xl font-bold mb-2">Social Media Integration</h1>
          <p className="text-muted-foreground">Connect your social accounts to enhance your networking experience</p>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
          <TabsList className="grid grid-cols-3 h-auto p-1">
            <TabsTrigger value="accounts" className="py-2">
              Accounts
            </TabsTrigger>
            <TabsTrigger value="notifications" className="py-2">
              Notifications
            </TabsTrigger>
            <TabsTrigger value="privacy" className="py-2">
              Privacy
            </TabsTrigger>
          </TabsList>

          <TabsContent value="accounts" className="space-y-6">
            <SocialConnectPanel />
          </TabsContent>

          <TabsContent value="notifications" className="space-y-6">
            <Card className="border-primary/20 shadow-sm">
              <CardHeader>
                <CardTitle className="text-lg">Notification Preferences</CardTitle>
                <CardDescription>Control what social media events trigger notifications</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-4">
                  <h3 className="font-medium">LinkedIn Notifications</h3>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <div>
                        <h4 className="text-sm font-medium">Job Changes</h4>
                        <p className="text-xs text-muted-foreground">When contacts change jobs</p>
                      </div>
                      <Switch
                        checked={notificationSettings.jobChanges}
                        onCheckedChange={() => toggleNotification("jobChanges")}
                      />
                    </div>

                    <div className="flex items-center justify-between">
                      <div>
                        <h4 className="text-sm font-medium">Work Anniversaries</h4>
                        <p className="text-xs text-muted-foreground">When contacts celebrate work milestones</p>
                      </div>
                      <Switch
                        checked={notificationSettings.workAnniversaries}
                        onCheckedChange={() => toggleNotification("workAnniversaries")}
                      />
                    </div>

                    <div className="flex items-center justify-between">
                      <div>
                        <h4 className="text-sm font-medium">Achievements</h4>
                        <p className="text-xs text-muted-foreground">Promotions, awards, and other achievements</p>
                      </div>
                      <Switch
                        checked={notificationSettings.achievements}
                        onCheckedChange={() => toggleNotification("achievements")}
                      />
                    </div>
                  </div>
                </div>

                <div className="space-y-4 pt-4 border-t">
                  <h3 className="font-medium">Facebook Notifications</h3>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <div>
                        <h4 className="text-sm font-medium">Birthdays</h4>
                        <p className="text-xs text-muted-foreground">Birthday reminders for your contacts</p>
                      </div>
                      <Switch
                        checked={notificationSettings.birthdays}
                        onCheckedChange={() => toggleNotification("birthdays")}
                      />
                    </div>

                    <div className="flex items-center justify-between">
                      <div>
                        <h4 className="text-sm font-medium">New Connections</h4>
                        <p className="text-xs text-muted-foreground">When contacts connect with people you know</p>
                      </div>
                      <Switch
                        checked={notificationSettings.newConnections}
                        onCheckedChange={() => toggleNotification("newConnections")}
                      />
                    </div>

                    <div className="flex items-center justify-between">
                      <div>
                        <h4 className="text-sm font-medium">Messages</h4>
                        <p className="text-xs text-muted-foreground">Notifications for new Facebook messages</p>
                      </div>
                      <Switch
                        checked={notificationSettings.messages}
                        onCheckedChange={() => toggleNotification("messages")}
                      />
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="privacy" className="space-y-6">
            <Card className="border-primary/20 shadow-sm">
              <CardHeader>
                <CardTitle className="text-lg">Privacy Settings</CardTitle>
                <CardDescription>
                  Control how your data is shared between NetworkMinder and social platforms
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-3">
                  <h3 className="font-medium">Data Sharing</h3>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <div>
                        <h4 className="text-sm font-medium">Share Contact Updates</h4>
                        <p className="text-xs text-muted-foreground">
                          Allow NetworkMinder to update social profiles with contact changes
                        </p>
                      </div>
                      <Switch defaultChecked={false} />
                    </div>

                    <div className="flex items-center justify-between">
                      <div>
                        <h4 className="text-sm font-medium">Allow Message Sync</h4>
                        <p className="text-xs text-muted-foreground">
                          Sync messages between NetworkMinder and social platforms
                        </p>
                      </div>
                      <Switch defaultChecked={true} />
                    </div>

                    <div className="flex items-center justify-between">
                      <div>
                        <h4 className="text-sm font-medium">Public Profile Visibility</h4>
                        <p className="text-xs text-muted-foreground">
                          Allow others to see your NetworkMinder profile via social links
                        </p>
                      </div>
                      <Switch defaultChecked={false} />
                    </div>
                  </div>
                </div>

                <div className="pt-4 border-t">
                  <Button variant="destructive" size="sm">
                    Disconnect All Social Accounts
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  )
}

