"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, BarChart, Calendar, Zap, Award, Share2, Sparkles } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { AIInsightsCard } from "@/components/ai-insights-card"
import { SmartMeetingScheduler } from "@/components/smart-meeting-scheduler"
import { NetworkEvents } from "@/components/network-events"
import { NetworkHealthDashboard } from "@/components/network-health-dashboard"
import { AchievementsShowcase } from "@/components/achievements-showcase"
import { SmartRecommendations } from "@/components/smart-recommendations"
import { ContextualFollowUp } from "@/components/contextual-follow-up"
import { GamifiedReferrals } from "@/components/gamified-referrals"

export default function InsightsPage() {
  const [activeTab, setActiveTab] = useState("overview")

  return (
    <div className="min-h-screen bg-background">
      <header className="sticky top-0 z-10 border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex h-14 items-center">
          <Link href="/">
            <Button variant="ghost">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Back
            </Button>
          </Link>
          <div className="ml-4">
            <h1 className="font-semibold">AI Insights & Tools</h1>
          </div>
        </div>
      </header>

      <main className="container py-6">
        <div className="mb-6">
          <h1 className="text-2xl font-bold mb-2">Network Intelligence</h1>
          <p className="text-muted-foreground">AI-powered insights and tools to enhance your networking</p>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
          <TabsList className="grid grid-cols-2 md:grid-cols-6 h-auto p-1">
            <TabsTrigger value="overview" className="py-2">
              <BarChart className="h-4 w-4 mr-2" />
              <span className="hidden sm:inline">Overview</span>
            </TabsTrigger>
            <TabsTrigger value="health" className="py-2">
              <Zap className="h-4 w-4 mr-2" />
              <span className="hidden sm:inline">Health</span>
            </TabsTrigger>
            <TabsTrigger value="achievements" className="py-2">
              <Award className="h-4 w-4 mr-2" />
              <span className="hidden sm:inline">Achievements</span>
            </TabsTrigger>
            <TabsTrigger value="recommendations" className="py-2">
              <Sparkles className="h-4 w-4 mr-2" />
              <span className="hidden sm:inline">Recommendations</span>
            </TabsTrigger>
            <TabsTrigger value="followups" className="py-2">
              <Calendar className="h-4 w-4 mr-2" />
              <span className="hidden sm:inline">Follow-ups</span>
            </TabsTrigger>
            <TabsTrigger value="referrals" className="py-2">
              <Share2 className="h-4 w-4 mr-2" />
              <span className="hidden sm:inline">Referrals</span>
            </TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-6">
            <div className="grid gap-6 md:grid-cols-2">
              <AIInsightsCard />

              <Card className="border-primary/20 shadow-sm">
                <CardHeader>
                  <CardTitle className="text-lg">Network Stats</CardTitle>
                  <CardDescription>Your networking activity at a glance</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-1 p-3 bg-muted/50 rounded-md text-center">
                      <div className="text-2xl font-bold text-primary">23</div>
                      <div className="text-sm text-muted-foreground">Active Contacts</div>
                    </div>
                    <div className="space-y-1 p-3 bg-muted/50 rounded-md text-center">
                      <div className="text-2xl font-bold text-primary">8</div>
                      <div className="text-sm text-muted-foreground">Follow-ups Due</div>
                    </div>
                    <div className="space-y-1 p-3 bg-muted/50 rounded-md text-center">
                      <div className="text-2xl font-bold text-highlight">3</div>
                      <div className="text-sm text-muted-foreground">Upcoming Events</div>
                    </div>
                    <div className="space-y-1 p-3 bg-muted/50 rounded-md text-center">
                      <div className="text-2xl font-bold text-highlight">12</div>
                      <div className="text-sm text-muted-foreground">New Opportunities</div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            <div className="grid gap-6 md:grid-cols-2">
              <SmartMeetingScheduler />
              <NetworkEvents />
            </div>
          </TabsContent>

          <TabsContent value="health" className="space-y-6">
            <NetworkHealthDashboard />
          </TabsContent>

          <TabsContent value="achievements" className="space-y-6">
            <AchievementsShowcase />
          </TabsContent>

          <TabsContent value="recommendations" className="space-y-6">
            <SmartRecommendations />
          </TabsContent>

          <TabsContent value="followups" className="space-y-6">
            <ContextualFollowUp />
          </TabsContent>

          <TabsContent value="referrals" className="space-y-6">
            <GamifiedReferrals />
          </TabsContent>
        </Tabs>
      </main>
    </div>
  )
}

