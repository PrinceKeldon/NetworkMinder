"use client"

import type React from "react"
import { useState, useRef, useEffect } from "react"
import { useSearchParams } from "next/navigation"
import { Send, User } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { SmartReplySuggestions } from "@/components/smart-reply-suggestions"
import { ConversationSummary } from "@/components/conversation-summary"
import { useAppStore } from "@/lib/data"

export default function ChatPage() {
  const searchParams = useSearchParams()
  const contactId = searchParams.get("contact") || ""
  const [activeContact, setActiveContact] = useState(contactId || "")
  const [message, setMessage] = useState("")
  const [showSummary, setShowSummary] = useState(false)
  const messagesEndRef = useRef<HTMLDivElement>(null)

  const contacts = useAppStore((state) => state.contacts)
  const messages = useAppStore((state) => state.messages)
  const addMessage = useAppStore((state) => state.addMessage)

  const activeContactId = Number.parseInt(activeContact)
  const activeContactData = contacts.find((c) => c.id === activeContactId)
  const conversation = activeContactId ? messages[activeContactId] || [] : []
  const lastContactMessage = conversation.filter((msg) => msg.sender === "contact").pop()

  useEffect(() => {
    if (messagesEndRef.current) {
      messagesEndRef.current.scrollIntoView({ behavior: "smooth" })
    }
  }, [conversation])

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault()

    if (!message.trim() || !activeContact) return

    const newMessage = {
      contactId: activeContactId,
      sender: "user" as const,
      text: message,
      time: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
      read: true,
    }

    addMessage(activeContactId, newMessage)
    setMessage("")

    // Simulate a reply after a short delay
    setTimeout(() => {
      const replyMessage = {
        contactId: activeContactId,
        sender: "contact" as const,
        text: "Thanks for your message! I'll get back to you soon.",
        time: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
        read: true,
      }

      addMessage(activeContactId, replyMessage)
    }, 1000)
  }

  const handleSmartReply = (replyText: string) => {
    setMessage(replyText)
  }

  return (
    <div className="flex h-[calc(100vh-3.5rem)] flex-col">
      <div className="flex flex-1 overflow-hidden">
        {/* Contacts sidebar */}
        <div className="w-full max-w-xs border-r hidden md:block">
          <div className="p-4">
            <h2 className="font-semibold mb-4">Contacts</h2>
            <div className="space-y-2">
              {contacts.map((contact) => {
                const contactMessages = messages[contact.id] || []
                const lastMessage = contactMessages.length > 0 ? contactMessages[contactMessages.length - 1] : null

                return (
                  <div
                    key={contact.id}
                    className={`flex items-center p-3 rounded-lg cursor-pointer ${
                      activeContact === contact.id.toString() ? "bg-primary/10" : "hover:bg-muted"
                    }`}
                    onClick={() => {
                      setActiveContact(contact.id.toString())
                      setShowSummary(false)
                    }}
                  >
                    <Avatar className="h-10 w-10 mr-3">
                      <AvatarImage src={contact.image} alt={contact.name} />
                      <AvatarFallback>{contact.name.charAt(0)}</AvatarFallback>
                    </Avatar>
                    <div className="flex-1 min-w-0">
                      <div className="flex justify-between items-baseline">
                        <p className="font-medium truncate">{contact.name}</p>
                        <span className="text-xs text-muted-foreground">
                          {lastMessage ? lastMessage.time : "No messages"}
                        </span>
                      </div>
                      <p className="text-sm text-muted-foreground truncate">
                        {lastMessage ? lastMessage.text : "Start a conversation"}
                      </p>
                    </div>
                  </div>
                )
              })}
            </div>
          </div>
        </div>

        {/* Chat area */}
        <div className="flex-1 flex flex-col">
          {activeContact ? (
            <>
              {/* Chat header */}
              <div className="border-b p-4 flex items-center">
                <Avatar className="h-10 w-10 mr-3">
                  <AvatarImage src={activeContactData?.image} alt={activeContactData?.name} />
                  <AvatarFallback>{activeContactData?.name?.charAt(0)}</AvatarFallback>
                </Avatar>
                <div>
                  <h2 className="font-medium">{activeContactData?.name}</h2>
                </div>
                <Button variant="ghost" size="sm" className="ml-auto" onClick={() => setShowSummary(!showSummary)}>
                  {showSummary ? "Hide Summary" : "AI Summary"}
                </Button>
              </div>

              {/* Messages or Summary */}
              {showSummary ? (
                <div className="flex-1 p-4">
                  <ConversationSummary contactName={activeContactData?.name || ""} />
                </div>
              ) : (
                <ScrollArea className="flex-1 p-4">
                  <div className="space-y-4">
                    {conversation.map((msg, index) => (
                      <div key={index} className={`flex ${msg.sender === "user" ? "justify-end" : "justify-start"}`}>
                        <div
                          className={`max-w-[75%] rounded-lg p-3 ${
                            msg.sender === "user" ? "bg-primary text-primary-foreground" : "bg-muted"
                          }`}
                        >
                          <p>{msg.text}</p>
                          <p className="text-xs mt-1 opacity-70">{msg.time}</p>
                        </div>
                      </div>
                    ))}
                    <div ref={messagesEndRef} />
                  </div>
                </ScrollArea>
              )}

              {/* Message input */}
              <div className="border-t">
                {lastContactMessage && !showSummary && (
                  <div className="px-4 pt-2">
                    <SmartReplySuggestions lastMessage={lastContactMessage.text} onSelectReply={handleSmartReply} />
                  </div>
                )}
                <form onSubmit={handleSendMessage} className="p-4 flex gap-2">
                  <Input
                    placeholder="Type a message..."
                    value={message}
                    onChange={(e) => setMessage(e.target.value)}
                    className="flex-1"
                  />
                  <Button type="submit" size="icon">
                    <Send className="h-4 w-4" />
                    <span className="sr-only">Send</span>
                  </Button>
                </form>
              </div>
            </>
          ) : (
            <div className="flex-1 flex flex-col items-center justify-center p-4 text-center">
              <User className="h-12 w-12 text-muted-foreground mb-4" />
              <h2 className="text-xl font-semibold mb-2">Select a contact</h2>
              <p className="text-muted-foreground max-w-md">Choose a contact from the list to start chatting</p>

              {/* Mobile contact selection */}
              <div className="mt-8 w-full max-w-md md:hidden">
                <h3 className="font-medium mb-4">Your Contacts</h3>
                <div className="space-y-2">
                  {contacts.map((contact) => (
                    <div
                      key={contact.id}
                      className="flex items-center p-3 rounded-lg border cursor-pointer hover:bg-muted"
                      onClick={() => setActiveContact(contact.id.toString())}
                    >
                      <Avatar className="h-10 w-10 mr-3">
                        <AvatarImage src={contact.image} alt={contact.name} />
                        <AvatarFallback>{contact.name.charAt(0)}</AvatarFallback>
                      </Avatar>
                      <div className="flex-1">
                        <p className="font-medium">{contact.name}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}

