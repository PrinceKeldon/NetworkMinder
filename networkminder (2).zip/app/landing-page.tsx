"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import Image from "next/image"
import { motion, AnimatePresence } from "framer-motion"
import {
  ChevronRight,
  ChevronLeft,
  Instagram,
  Linkedin,
  Facebook,
  MessageCircle,
  Calendar,
  Sparkles,
  ArrowRight,
  Star,
  Users,
  Bell,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"

// Feature slides for the carousel
const featureSlides = [
  {
    id: 1,
    title: "Import Contacts",
    description: "Instantly import your contacts from Instagram, LinkedIn, and Facebook.",
    icon: (
      <div className="flex space-x-1">
        <Instagram className="h-5 w-5 text-pink-500" />
        <Linkedin className="h-5 w-5 text-[#0077B5]" />
        <Facebook className="h-5 w-5 text-[#1877F2]" />
      </div>
    ),
    image: "/placeholder.svg?height=300&width=400",
  },
  {
    id: 2,
    title: "AI-Powered Insights",
    description: "AI-driven suggestions to build stronger, meaningful connections.",
    icon: <Sparkles className="h-5 w-5 text-highlight" />,
    image: "/placeholder.svg?height=300&width=400",
  },
  {
    id: 3,
    title: "Easy Follow-ups",
    description: "Set contextual reminders and never miss another follow-up opportunity.",
    icon: <Calendar className="h-5 w-5 text-primary" />,
    image: "/placeholder.svg?height=300&width=400",
  },
  {
    id: 4,
    title: "Social Notifications",
    description: "Receive instant notifications when tagged or mentioned on social platforms.",
    icon: <Bell className="h-5 w-5 text-red-500" />,
    image: "/placeholder.svg?height=300&width=400",
  },
  {
    id: 5,
    title: "Chat Integration",
    description: "In-app messaging to connect instantly with your contacts.",
    icon: <MessageCircle className="h-5 w-5 text-green-500" />,
    image: "/placeholder.svg?height=300&width=400",
  },
]

// Testimonials
const testimonials = [
  {
    id: 1,
    name: "Alex Johnson",
    role: "Marketing Director",
    quote: "NetworkMinder has transformed how I manage my professional relationships. The AI suggestions are spot on!",
    avatar: "/placeholder.svg?height=60&width=60",
  },
  {
    id: 2,
    name: "Sam Rivera",
    role: "Startup Founder",
    quote: "I used to forget follow-ups all the time. Now NetworkMinder reminds me at just the right moment.",
    avatar: "/placeholder.svg?height=60&width=60",
  },
  {
    id: 3,
    name: "Jordan Lee",
    role: "UX Designer",
    quote:
      "The social media integration is seamless. I love getting notifications when my contacts post important updates.",
    avatar: "/placeholder.svg?height=60&width=60",
  },
]

export default function LandingPage() {
  const router = useRouter()
  const [currentSlide, setCurrentSlide] = useState(0)

  // Auto-scroll feature carousel
  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % featureSlides.length)
    }, 4000)

    return () => clearInterval(interval)
  }, [])

  const handleGetStarted = () => {
    router.push("/")
  }

  return (
    <div className="min-h-screen flex flex-col">
      {/* Hero Section */}
      <section className="relative min-h-[80vh] flex items-center justify-center overflow-hidden">
        {/* Background gradient */}
        <div className="absolute inset-0 bg-gradient-to-br from-primary/90 via-primary/70 to-highlight/80 z-0" />

        {/* Content */}
        <div className="container relative z-10 px-4 py-16 sm:px-6 lg:px-8 flex flex-col items-center text-white">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="text-center max-w-3xl mx-auto"
          >
            <div className="mb-6 flex justify-center">
              <div className="h-20 w-20 rounded-full bg-white/20 backdrop-blur-sm flex items-center justify-center">
                <Users className="h-10 w-10" />
              </div>
            </div>

            <h1 className="text-4xl sm:text-5xl md:text-6xl font-bold tracking-tight mb-4">NetworkMinder</h1>

            <p className="text-xl sm:text-2xl mb-8 text-white/90">Simplify Networking. Deepen Connections.</p>

            <Button
              size="lg"
              onClick={handleGetStarted}
              className="bg-white text-primary hover:bg-white/90 text-lg px-8 py-6 h-auto"
            >
              Get Started
              <ArrowRight className="ml-2 h-5 w-5" />
            </Button>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 40 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.3 }}
            className="mt-12 relative w-full max-w-4xl"
          >
            <div className="relative h-[300px] sm:h-[400px] rounded-xl overflow-hidden shadow-2xl">
              <Image
                src="/placeholder.svg?height=800&width=1200"
                alt="NetworkMinder App"
                fill
                className="object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent flex items-end">
                <div className="p-6 text-white">
                  <h3 className="text-xl font-bold">Effortless Networking</h3>
                  <p className="text-white/80">Manage your professional and personal connections in one place</p>
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Feature Highlights */}
      <section className="py-16 bg-white dark:bg-background">
        <div className="container px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <Badge className="mb-2 px-3 py-1 text-sm bg-primary/10 text-primary dark:bg-primary/20">Features</Badge>
            <h2 className="text-3xl sm:text-4xl font-bold">Everything you need to network effectively</h2>
            <p className="mt-4 text-lg text-muted-foreground max-w-2xl mx-auto">
              NetworkMinder combines powerful tools with an intuitive interface to make networking effortless and
              effective.
            </p>
          </div>

          <div className="relative max-w-4xl mx-auto">
            {/* Feature carousel */}
            <div className="relative h-[400px] sm:h-[500px] overflow-hidden rounded-xl border">
              <AnimatePresence mode="wait">
                <motion.div
                  key={currentSlide}
                  initial={{ opacity: 0, x: 100 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -100 }}
                  transition={{ duration: 0.5 }}
                  className="absolute inset-0 flex flex-col md:flex-row"
                >
                  <div className="md:w-1/2 p-8 flex flex-col justify-center">
                    <div className="mb-4 p-2 w-fit rounded-full bg-primary/10 dark:bg-primary/20">
                      {featureSlides[currentSlide].icon}
                    </div>
                    <h3 className="text-2xl font-bold mb-4">{featureSlides[currentSlide].title}</h3>
                    <p className="text-muted-foreground">{featureSlides[currentSlide].description}</p>
                  </div>
                  <div className="md:w-1/2 relative">
                    <div className="absolute inset-0 flex items-center justify-center bg-muted/30">
                      <Image
                        src={featureSlides[currentSlide].image || "/placeholder.svg"}
                        alt={featureSlides[currentSlide].title}
                        fill
                        className="object-cover"
                      />
                    </div>
                  </div>
                </motion.div>
              </AnimatePresence>
            </div>

            {/* Carousel controls */}
            <div className="flex justify-center mt-6 gap-2">
              {featureSlides.map((_, index) => (
                <button
                  key={index}
                  onClick={() => setCurrentSlide(index)}
                  className={`h-2 rounded-full transition-all ${
                    currentSlide === index ? "w-8 bg-primary" : "w-2 bg-primary/30"
                  }`}
                  aria-label={`Go to slide ${index + 1}`}
                />
              ))}
            </div>

            <div className="absolute top-1/2 -translate-y-1/2 -left-4 sm:-left-6">
              <Button
                variant="outline"
                size="icon"
                className="rounded-full bg-background/80 backdrop-blur-sm"
                onClick={() => setCurrentSlide((prev) => (prev - 1 + featureSlides.length) % featureSlides.length)}
              >
                <ChevronLeft className="h-4 w-4" />
              </Button>
            </div>

            <div className="absolute top-1/2 -translate-y-1/2 -right-4 sm:-right-6">
              <Button
                variant="outline"
                size="icon"
                className="rounded-full bg-background/80 backdrop-blur-sm"
                onClick={() => setCurrentSlide((prev) => (prev + 1) % featureSlides.length)}
              >
                <ChevronRight className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-16 bg-muted/30 dark:bg-muted/10">
        <div className="container px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <Badge className="mb-2 px-3 py-1 text-sm bg-highlight/10 text-highlight dark:bg-highlight/20">
              Testimonials
            </Badge>
            <h2 className="text-3xl sm:text-4xl font-bold">What our users say</h2>
            <p className="mt-4 text-lg text-muted-foreground max-w-2xl mx-auto">
              Join thousands of professionals who have transformed their networking experience with NetworkMinder.
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-6 max-w-5xl mx-auto">
            {testimonials.map((testimonial) => (
              <Card key={testimonial.id} className="overflow-hidden border-primary/10">
                <div className="p-6">
                  <div className="flex items-center mb-4">
                    <div className="relative h-12 w-12 rounded-full overflow-hidden mr-4">
                      <Image
                        src={testimonial.avatar || "/placeholder.svg"}
                        alt={testimonial.name}
                        fill
                        className="object-cover"
                      />
                    </div>
                    <div>
                      <h4 className="font-medium">{testimonial.name}</h4>
                      <p className="text-sm text-muted-foreground">{testimonial.role}</p>
                    </div>
                  </div>
                  <div className="mb-4">
                    {[1, 2, 3, 4, 5].map((star) => (
                      <Star key={star} className="inline-block h-4 w-4 fill-current text-yellow-400" />
                    ))}
                  </div>
                  <p className="italic text-muted-foreground">"{testimonial.quote}"</p>
                </div>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Call to Action */}
      <section className="py-16 bg-gradient-to-r from-primary to-highlight text-white">
        <div className="container px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl sm:text-4xl font-bold mb-6">Start Networking Now</h2>
          <p className="text-xl mb-8 max-w-2xl mx-auto text-white/90">
            Join NetworkMinder today and transform how you build and maintain your professional network.
          </p>
          <Button
            size="lg"
            onClick={handleGetStarted}
            className="bg-white text-primary hover:bg-white/90 text-lg px-8 py-6 h-auto"
          >
            Get Started
            <ArrowRight className="ml-2 h-5 w-5" />
          </Button>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-8 bg-background border-t">
        <div className="container px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="mb-4 md:mb-0">
              <div className="flex items-center">
                <div className="h-8 w-8 rounded-full bg-primary/20 flex items-center justify-center mr-2">
                  <Users className="h-4 w-4 text-primary" />
                </div>
                <span className="font-bold text-lg">NetworkMinder</span>
              </div>
              <p className="text-sm text-muted-foreground mt-1">© 2025 NetworkMinder. All rights reserved.</p>
            </div>

            <div className="flex flex-wrap gap-4 md:gap-8">
              <a href="#" className="text-sm text-muted-foreground hover:text-foreground">
                Privacy Policy
              </a>
              <a href="#" className="text-sm text-muted-foreground hover:text-foreground">
                Terms of Use
              </a>
              <a href="#" className="text-sm text-muted-foreground hover:text-foreground">
                Contact Us
              </a>
            </div>

            <div className="mt-4 md:mt-0 flex gap-4">
              <Button variant="ghost" size="icon">
                <Linkedin className="h-5 w-5 text-[#0077B5]" />
              </Button>
              <Button variant="ghost" size="icon">
                <Instagram className="h-5 w-5 text-pink-500" />
              </Button>
              <Button variant="ghost" size="icon">
                <Facebook className="h-5 w-5 text-[#1877F2]" />
              </Button>
            </div>
          </div>
        </div>
      </footer>
    </div>
  )
}

