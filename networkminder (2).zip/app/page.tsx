"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { PlusCircle, Zap } from "lucide-react"
import { Button } from "@/components/ui/button"
import ContactList from "@/components/contact-list"
import { InstagramNotification } from "@/components/instagram-notification"
import { SocialEventNotification } from "@/components/social-event-notification"
import { WelcomeScreen } from "@/components/welcome-screen"
import { LoadingScreen } from "@/components/loading-screen"
import { Badge } from "@/components/ui/badge"
import { useAppStore } from "@/lib/data"
import { registerServiceWorker } from "@/app/sw-register"

export default function Home() {
  const [showInstagramNotification, setShowInstagramNotification] = useState(false)
  const [showSocialNotification, setShowSocialNotification] = useState(false)
  const [showWelcome, setShowWelcome] = useState(false)
  const [showAchievementBadge, setShowAchievementBadge] = useState(false)
  const [isLoading, setIsLoading] = useState(true)

  const user = useAppStore((state) => state.user)
  const addNotification = useAppStore((state) => state.addNotification)

  // Register service worker for PWA functionality
  useEffect(() => {
    registerServiceWorker()
  }, [])

  useEffect(() => {
    // Check if this is the first visit
    const firstVisit = localStorage.getItem("firstVisit") !== "false"

    // Show Instagram notification after loading is complete
    const instagramTimer = setTimeout(
      () => {
        if (!isLoading) {
          setShowInstagramNotification(true)

          // Add to notifications
          addNotification({
            type: "instagram_tag",
            user: {
              id: 3,
              name: "Jordan Lee",
              handle: "@jordanlee",
              image: "/placeholder.svg?height=40&width=40",
            },
            content: "tagged you in a post",
            postImage: "/placeholder.svg?height=100&width=100",
            time: "Just now",
            read: false,
          })
        }
      },
      isLoading ? 15000 : 10000,
    )

    // Show social notification after Instagram notification
    const socialTimer = setTimeout(
      () => {
        if (!isLoading) {
          setShowSocialNotification(true)
        }
      },
      isLoading ? 25000 : 20000,
    )

    // Show achievement badge after loading is complete
    const achievementTimer = setTimeout(
      () => {
        if (!isLoading) {
          setShowAchievementBadge(true)
        }
      },
      isLoading ? 10000 : 5000,
    )

    // If it's the first visit, show welcome screen after loading
    if (firstVisit && !isLoading) {
      setShowWelcome(true)
      localStorage.setItem("firstVisit", "false")
    }

    return () => {
      clearTimeout(instagramTimer)
      clearTimeout(socialTimer)
      clearTimeout(achievementTimer)
    }
  }, [isLoading, addNotification])

  // Handle loading completion
  const handleLoadingComplete = () => {
    setIsLoading(false)

    // Check if this is the first visit
    const firstVisit = localStorage.getItem("firstVisit") !== "false"
    if (firstVisit) {
      setShowWelcome(true)
      localStorage.setItem("firstVisit", "false")
    }
  }

  if (isLoading) {
    return <LoadingScreen onComplete={handleLoadingComplete} />
  }

  return (
    <div className="min-h-screen bg-background">
      {showWelcome && <WelcomeScreen onComplete={() => setShowWelcome(false)} />}

      <main className="container py-6">
        <div className="flex justify-between items-center mb-6">
          <h1 className="text-2xl font-bold">My Contacts</h1>
          <div className="flex items-center gap-2">
            <Link href="/insights/recommendations">
              <Button variant="outline" className="hidden sm:flex">
                <Zap className="h-4 w-4 mr-2 text-highlight" />
                Smart Recommendations
              </Button>
            </Link>
            <Link href="/add-contact">
              <Button>
                <PlusCircle className="mr-2 h-4 w-4" />
                Add Contact
              </Button>
            </Link>
          </div>
        </div>

        <div className="mb-6 flex items-center justify-between">
          <div className="flex gap-2 overflow-x-auto pb-2 scrollbar-hide">
            <Badge
              variant="outline"
              className="bg-[#0077B5]/10 border-[#0077B5]/20 text-[#0077B5] cursor-pointer whitespace-nowrap"
            >
              LinkedIn
            </Badge>
            <Badge
              variant="outline"
              className="bg-[#1877F2]/10 border-[#1877F2]/20 text-[#1877F2] cursor-pointer whitespace-nowrap"
            >
              Facebook
            </Badge>
            <Badge variant="outline" className="cursor-pointer whitespace-nowrap">
              All Contacts
            </Badge>
          </div>

          <div className="flex items-center gap-2 ml-2">
            <Badge variant="secondary" className="cursor-pointer whitespace-nowrap">
              Level {user.level}
            </Badge>
            <Badge variant="outline" className="bg-highlight/10 text-highlight cursor-pointer whitespace-nowrap">
              {user.points} pts
            </Badge>
          </div>
        </div>

        <ContactList />
      </main>

      {showInstagramNotification && <InstagramNotification onClose={() => setShowInstagramNotification(false)} />}

      {showSocialNotification && (
        <SocialEventNotification type="birthday" onClose={() => setShowSocialNotification(false)} />
      )}
    </div>
  )
}

