"use client"

import { useState } from "react"
import { Linkedin, Facebook, Check, Link2, RefreshCw } from "lucide-react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Switch } from "@/components/ui/switch"
import { Badge } from "@/components/ui/badge"
import { useToast } from "@/hooks/use-toast"

export function SocialConnectPanel() {
  const { toast } = useToast()
  const [linkedInConnected, setLinkedInConnected] = useState(false)
  const [facebookConnected, setFacebookConnected] = useState(false)
  const [syncSettings, setSyncSettings] = useState({
    autoSync: true,
    importContacts: true,
    importEvents: true,
    importMessages: true,
  })
  const [isLoading, setIsLoading] = useState({
    linkedin: false,
    facebook: false,
    sync: false,
  })

  const handleLinkedInConnect = () => {
    if (linkedInConnected) {
      // Disconnect logic
      setLinkedInConnected(false)
      toast({
        title: "LinkedIn Disconnected",
        description: "Your LinkedIn account has been disconnected",
      })
      return
    }

    // Connect logic
    setIsLoading((prev) => ({ ...prev, linkedin: true }))

    // Simulate API call
    setTimeout(() => {
      setLinkedInConnected(true)
      setIsLoading((prev) => ({ ...prev, linkedin: false }))
      toast({
        title: "LinkedIn Connected",
        description: "Your LinkedIn account has been successfully connected",
      })
    }, 1500)
  }

  const handleFacebookConnect = () => {
    if (facebookConnected) {
      // Disconnect logic
      setFacebookConnected(false)
      toast({
        title: "Facebook Disconnected",
        description: "Your Facebook account has been disconnected",
      })
      return
    }

    // Connect logic
    setIsLoading((prev) => ({ ...prev, facebook: true }))

    // Simulate API call
    setTimeout(() => {
      setFacebookConnected(true)
      setIsLoading((prev) => ({ ...prev, facebook: false }))
      toast({
        title: "Facebook Connected",
        description: "Your Facebook account has been successfully connected",
      })
    }, 1500)
  }

  const handleSyncNow = () => {
    if (!linkedInConnected && !facebookConnected) {
      toast({
        title: "No accounts connected",
        description: "Please connect at least one social account to sync",
        variant: "destructive",
      })
      return
    }

    setIsLoading((prev) => ({ ...prev, sync: true }))

    // Simulate sync
    setTimeout(() => {
      setIsLoading((prev) => ({ ...prev, sync: false }))
      toast({
        title: "Sync Complete",
        description: `Successfully synced data from ${
          linkedInConnected && facebookConnected ? "LinkedIn and Facebook" : linkedInConnected ? "LinkedIn" : "Facebook"
        }`,
      })
    }, 2000)
  }

  const toggleSetting = (setting: keyof typeof syncSettings) => {
    setSyncSettings((prev) => ({
      ...prev,
      [setting]: !prev[setting],
    }))
  }

  return (
    <Card className="border-primary/20 shadow-sm">
      <CardHeader>
        <CardTitle className="text-lg">Social Media Integration</CardTitle>
        <CardDescription>Connect your social accounts to enhance your networking</CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <div className="h-10 w-10 rounded-full bg-[#0077B5] flex items-center justify-center mr-3">
                <Linkedin className="h-5 w-5 text-white" />
              </div>
              <div>
                <h3 className="font-medium">LinkedIn</h3>
                <p className="text-sm text-muted-foreground">Import professional contacts</p>
              </div>
            </div>
            <Button
              variant={linkedInConnected ? "outline" : "default"}
              className={linkedInConnected ? "border-green-500 text-green-600" : ""}
              onClick={handleLinkedInConnect}
              disabled={isLoading.linkedin}
            >
              {isLoading.linkedin ? (
                <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
              ) : linkedInConnected ? (
                <Check className="h-4 w-4 mr-2" />
              ) : (
                <Link2 className="h-4 w-4 mr-2" />
              )}
              {linkedInConnected ? "Connected" : "Connect"}
            </Button>
          </div>

          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <div className="h-10 w-10 rounded-full bg-[#1877F2] flex items-center justify-center mr-3">
                <Facebook className="h-5 w-5 text-white" />
              </div>
              <div>
                <h3 className="font-medium">Facebook</h3>
                <p className="text-sm text-muted-foreground">Import personal connections</p>
              </div>
            </div>
            <Button
              variant={facebookConnected ? "outline" : "default"}
              className={facebookConnected ? "border-green-500 text-green-600" : ""}
              onClick={handleFacebookConnect}
              disabled={isLoading.facebook}
            >
              {isLoading.facebook ? (
                <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
              ) : facebookConnected ? (
                <Check className="h-4 w-4 mr-2" />
              ) : (
                <Link2 className="h-4 w-4 mr-2" />
              )}
              {facebookConnected ? "Connected" : "Connect"}
            </Button>
          </div>
        </div>

        {(linkedInConnected || facebookConnected) && (
          <div className="pt-2 border-t">
            <h3 className="font-medium mb-3">Sync Settings</h3>
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <div>
                  <h4 className="text-sm font-medium">Auto-sync</h4>
                  <p className="text-xs text-muted-foreground">Automatically sync data daily</p>
                </div>
                <Switch checked={syncSettings.autoSync} onCheckedChange={() => toggleSetting("autoSync")} />
              </div>

              <div className="flex items-center justify-between">
                <div>
                  <h4 className="text-sm font-medium">Import Contacts</h4>
                  <p className="text-xs text-muted-foreground">Import new connections</p>
                </div>
                <Switch checked={syncSettings.importContacts} onCheckedChange={() => toggleSetting("importContacts")} />
              </div>

              <div className="flex items-center justify-between">
                <div>
                  <h4 className="text-sm font-medium">Import Events</h4>
                  <p className="text-xs text-muted-foreground">Birthdays, job changes, etc.</p>
                </div>
                <Switch checked={syncSettings.importEvents} onCheckedChange={() => toggleSetting("importEvents")} />
              </div>

              <div className="flex items-center justify-between">
                <div>
                  <h4 className="text-sm font-medium">Import Messages</h4>
                  <p className="text-xs text-muted-foreground">Sync recent messages</p>
                </div>
                <Switch checked={syncSettings.importMessages} onCheckedChange={() => toggleSetting("importMessages")} />
              </div>
            </div>
          </div>
        )}

        {(linkedInConnected || facebookConnected) && (
          <div className="flex items-center justify-between pt-2">
            <div className="text-sm text-muted-foreground">
              Last synced: {linkedInConnected || facebookConnected ? "Never" : "N/A"}
            </div>
            <Button variant="outline" size="sm" onClick={handleSyncNow} disabled={isLoading.sync}>
              {isLoading.sync ? (
                <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
              ) : (
                <RefreshCw className="h-4 w-4 mr-2" />
              )}
              Sync Now
            </Button>
          </div>
        )}
      </CardContent>
      {(linkedInConnected || facebookConnected) && (
        <CardFooter className="border-t pt-4 flex justify-between">
          <div className="flex space-x-2">
            {linkedInConnected && (
              <Badge variant="outline" className="bg-[#0077B5]/10 border-[#0077B5]/20 text-[#0077B5]">
                <Linkedin className="h-3 w-3 mr-1" />
                LinkedIn
              </Badge>
            )}
            {facebookConnected && (
              <Badge variant="outline" className="bg-[#1877F2]/10 border-[#1877F2]/20 text-[#1877F2]">
                <Facebook className="h-3 w-3 mr-1" />
                Facebook
              </Badge>
            )}
          </div>
          <Button size="sm" className="bg-primary hover:bg-primary/90">
            Import Contacts
          </Button>
        </CardFooter>
      )}
    </Card>
  )
}

