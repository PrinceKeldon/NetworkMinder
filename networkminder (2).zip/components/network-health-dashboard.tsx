"use client"

import { useState } from "react"
import { PieChart, Users, TrendingUp, Activity, Filter, Download } from "lucide-react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import {
  Bar,
  BarChart as RechartsBarChart,
  CartesianGrid,
  Cell,
  Legend,
  Line,
  LineChart as RechartsLineChart,
  Pie,
  PieChart as RechartsPieChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts"

// Mock data for network health metrics
const networkGrowthData = [
  { month: "Jan", connections: 5, interactions: 12 },
  { month: "Feb", connections: 8, interactions: 18 },
  { month: "Mar", connections: 12, interactions: 24 },
  { month: "Apr", connections: 15, interactions: 30 },
  { month: "May", connections: 18, interactions: 28 },
  { month: "Jun", connections: 22, interactions: 36 },
]

const interactionTypeData = [
  { name: "Messages", value: 45, color: "#3b82f6" },
  { name: "Meetings", value: 20, color: "#eab308" },
  { name: "Social", value: 15, color: "#10b981" },
  { name: "Events", value: 10, color: "#8b5cf6" },
  { name: "Other", value: 10, color: "#f97316" },
]

const connectionStrengthData = [
  { name: "Strong", value: 30, color: "#10b981" },
  { name: "Medium", value: 45, color: "#eab308" },
  { name: "Weak", value: 25, color: "#ef4444" },
]

const platformDistributionData = [
  { name: "LinkedIn", value: 55, color: "#0077B5" },
  { name: "Facebook", value: 25, color: "#1877F2" },
  { name: "Direct", value: 20, color: "#8b5cf6" },
]

const followUpCompletionData = [
  { month: "Jan", completed: 8, missed: 2 },
  { month: "Feb", completed: 10, missed: 3 },
  { month: "Mar", completed: 12, missed: 1 },
  { month: "Apr", completed: 9, missed: 4 },
  { month: "May", completed: 14, missed: 2 },
  { month: "Jun", completed: 16, missed: 1 },
]

export function NetworkHealthDashboard() {
  const [activeTab, setActiveTab] = useState("overview")
  const [timeRange, setTimeRange] = useState("6m")

  // Calculate network health score (mock algorithm)
  const calculateHealthScore = () => {
    // This would be a more complex algorithm in a real app
    const connectionGrowth =
      networkGrowthData[networkGrowthData.length - 1].connections / networkGrowthData[0].connections
    const interactionRate =
      networkGrowthData[networkGrowthData.length - 1].interactions /
      networkGrowthData[networkGrowthData.length - 1].connections
    const strongConnections = connectionStrengthData[0].value / 100

    // Weight factors and calculate score out of 100
    return Math.min(Math.round((connectionGrowth * 0.3 + interactionRate * 0.5 + strongConnections * 0.2) * 100), 100)
  }

  const healthScore = calculateHealthScore()

  // Determine health status based on score
  const getHealthStatus = (score: number) => {
    if (score >= 80) return { label: "Excellent", color: "text-green-500" }
    if (score >= 60) return { label: "Good", color: "text-blue-500" }
    if (score >= 40) return { label: "Fair", color: "text-yellow-500" }
    return { label: "Needs Attention", color: "text-red-500" }
  }

  const healthStatus = getHealthStatus(healthScore)

  // Calculate key metrics
  const totalConnections = networkGrowthData[networkGrowthData.length - 1].connections
  const connectionGrowth = Math.round(
    ((networkGrowthData[networkGrowthData.length - 1].connections - networkGrowthData[0].connections) /
      networkGrowthData[0].connections) *
      100,
  )
  const avgInteractionsPerMonth = Math.round(
    networkGrowthData.reduce((sum, item) => sum + item.interactions, 0) / networkGrowthData.length,
  )
  const followUpRate = Math.round(
    (followUpCompletionData.reduce((sum, item) => sum + item.completed, 0) /
      followUpCompletionData.reduce((sum, item) => sum + item.completed + item.missed, 0)) *
      100,
  )

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h2 className="text-2xl font-bold">Network Health Dashboard</h2>
          <p className="text-muted-foreground">AI-powered insights into your networking effectiveness</p>
        </div>
        <div className="flex items-center gap-2">
          <Select value={timeRange} onValueChange={setTimeRange}>
            <SelectTrigger className="w-[120px]">
              <SelectValue placeholder="Time Range" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="1m">Last Month</SelectItem>
              <SelectItem value="3m">Last 3 Months</SelectItem>
              <SelectItem value="6m">Last 6 Months</SelectItem>
              <SelectItem value="1y">Last Year</SelectItem>
            </SelectContent>
          </Select>
          <Button variant="outline" size="icon">
            <Filter className="h-4 w-4" />
          </Button>
          <Button variant="outline" size="icon">
            <Download className="h-4 w-4" />
          </Button>
        </div>
      </div>

      <div className="grid gap-6 md:grid-cols-4">
        <Card className="border-primary/20">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Network Health</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-baseline justify-between">
              <div className="text-3xl font-bold">{healthScore}</div>
              <Badge
                className={`${healthStatus.color.replace("text-", "bg-").replace("500", "100")} ${healthStatus.color}`}
              >
                {healthStatus.label}
              </Badge>
            </div>
            <div className="mt-4 h-2 w-full bg-muted rounded-full overflow-hidden">
              <div
                className={`h-full ${
                  healthScore >= 80
                    ? "bg-green-500"
                    : healthScore >= 60
                      ? "bg-blue-500"
                      : healthScore >= 40
                        ? "bg-yellow-500"
                        : "bg-red-500"
                }`}
                style={{ width: `${healthScore}%` }}
              />
            </div>
          </CardContent>
        </Card>

        <Card className="border-primary/20">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Total Connections</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-baseline justify-between">
              <div className="text-3xl font-bold">{totalConnections}</div>
              <Badge className="bg-green-100 text-green-500">+{connectionGrowth}%</Badge>
            </div>
            <p className="text-xs text-muted-foreground mt-1">vs. previous period</p>
          </CardContent>
        </Card>

        <Card className="border-primary/20">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Avg. Interactions</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-baseline justify-between">
              <div className="text-3xl font-bold">{avgInteractionsPerMonth}</div>
              <Badge className="bg-blue-100 text-blue-500">Monthly</Badge>
            </div>
            <p className="text-xs text-muted-foreground mt-1">Across all connections</p>
          </CardContent>
        </Card>

        <Card className="border-primary/20">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Follow-up Rate</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-baseline justify-between">
              <div className="text-3xl font-bold">{followUpRate}%</div>
              <Badge className={followUpRate >= 80 ? "bg-green-100 text-green-500" : "bg-yellow-100 text-yellow-500"}>
                {followUpRate >= 80 ? "Good" : "Improve"}
              </Badge>
            </div>
            <p className="text-xs text-muted-foreground mt-1">Completed follow-ups</p>
          </CardContent>
        </Card>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
        <TabsList className="grid grid-cols-4 h-auto p-1">
          <TabsTrigger value="overview" className="py-2">
            <Activity className="h-4 w-4 mr-2" />
            <span className="hidden sm:inline">Overview</span>
          </TabsTrigger>
          <TabsTrigger value="growth" className="py-2">
            <TrendingUp className="h-4 w-4 mr-2" />
            <span className="hidden sm:inline">Growth</span>
          </TabsTrigger>
          <TabsTrigger value="interactions" className="py-2">
            <Users className="h-4 w-4 mr-2" />
            <span className="hidden sm:inline">Interactions</span>
          </TabsTrigger>
          <TabsTrigger value="platforms" className="py-2">
            <PieChart className="h-4 w-4 mr-2" />
            <span className="hidden sm:inline">Platforms</span>
          </TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6">
          <div className="grid gap-6 md:grid-cols-2">
            <Card className="border-primary/20">
              <CardHeader>
                <CardTitle className="text-lg">Network Growth</CardTitle>
                <CardDescription>Connections and interactions over time</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-80">
                  <ResponsiveContainer width="100%" height="100%">
                    <RechartsLineChart data={networkGrowthData} margin={{ top: 20, right: 30, left: 0, bottom: 0 }}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="month" />
                      <YAxis />
                      <Tooltip />
                      <Legend />
                      <Line
                        type="monotone"
                        dataKey="connections"
                        stroke="#3b82f6"
                        strokeWidth={2}
                        activeDot={{ r: 8 }}
                      />
                      <Line type="monotone" dataKey="interactions" stroke="#eab308" strokeWidth={2} />
                    </RechartsLineChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>

            <Card className="border-primary/20">
              <CardHeader>
                <CardTitle className="text-lg">Connection Strength</CardTitle>
                <CardDescription>Distribution of your network by relationship strength</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-80">
                  <ResponsiveContainer width="100%" height="100%">
                    <RechartsPieChart>
                      <Pie
                        data={connectionStrengthData}
                        cx="50%"
                        cy="50%"
                        innerRadius={60}
                        outerRadius={100}
                        paddingAngle={5}
                        dataKey="value"
                        label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                      >
                        {connectionStrengthData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={entry.color} />
                        ))}
                      </Pie>
                      <Tooltip />
                      <Legend />
                    </RechartsPieChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
          </div>

          <Card className="border-primary/20">
            <CardHeader>
              <CardTitle className="text-lg">Follow-up Performance</CardTitle>
              <CardDescription>Completed vs. missed follow-ups over time</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-80">
                <ResponsiveContainer width="100%" height="100%">
                  <RechartsBarChart data={followUpCompletionData} margin={{ top: 20, right: 30, left: 0, bottom: 0 }}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="month" />
                    <YAxis />
                    <Tooltip />
                    <Legend />
                    <Bar dataKey="completed" stackId="a" fill="#10b981" name="Completed" />
                    <Bar dataKey="missed" stackId="a" fill="#ef4444" name="Missed" />
                  </RechartsBarChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="growth" className="space-y-6">
          <Card className="border-primary/20">
            <CardHeader>
              <CardTitle className="text-lg">Network Growth Trends</CardTitle>
              <CardDescription>Detailed analysis of your network expansion</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-96">
                <ResponsiveContainer width="100%" height="100%">
                  <RechartsLineChart data={networkGrowthData} margin={{ top: 20, right: 30, left: 0, bottom: 0 }}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="month" />
                    <YAxis />
                    <Tooltip />
                    <Legend />
                    <Line type="monotone" dataKey="connections" stroke="#3b82f6" strokeWidth={2} activeDot={{ r: 8 }} />
                    <Line type="monotone" dataKey="interactions" stroke="#eab308" strokeWidth={2} />
                  </RechartsLineChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
            <CardFooter className="border-t pt-4">
              <div className="space-y-2 w-full">
                <h4 className="font-medium">AI Insights</h4>
                <div className="p-3 bg-blue-50 text-blue-700 rounded-md dark:bg-blue-900/30 dark:text-blue-300">
                  <p className="text-sm">
                    Your network is growing steadily with a 340% increase over the last 6 months. To accelerate growth,
                    consider attending 2-3 industry events per month and increasing your LinkedIn engagement by 25%.
                  </p>
                </div>
              </div>
            </CardFooter>
          </Card>
        </TabsContent>

        <TabsContent value="interactions" className="space-y-6">
          <div className="grid gap-6 md:grid-cols-2">
            <Card className="border-primary/20">
              <CardHeader>
                <CardTitle className="text-lg">Interaction Types</CardTitle>
                <CardDescription>Breakdown of how you engage with your network</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-80">
                  <ResponsiveContainer width="100%" height="100%">
                    <RechartsPieChart>
                      <Pie
                        data={interactionTypeData}
                        cx="50%"
                        cy="50%"
                        outerRadius={100}
                        dataKey="value"
                        label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                      >
                        {interactionTypeData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={entry.color} />
                        ))}
                      </Pie>
                      <Tooltip />
                      <Legend />
                    </RechartsPieChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>

            <Card className="border-primary/20">
              <CardHeader>
                <CardTitle className="text-lg">Interaction Frequency</CardTitle>
                <CardDescription>How often you engage with your connections</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-80">
                  <ResponsiveContainer width="100%" height="100%">
                    <RechartsBarChart
                      data={[
                        { frequency: "Weekly", contacts: 5 },
                        { frequency: "Monthly", contacts: 12 },
                        { frequency: "Quarterly", contacts: 18 },
                        { frequency: "Yearly", contacts: 8 },
                        { frequency: "Inactive", contacts: 5 },
                      ]}
                    >
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="frequency" />
                      <YAxis />
                      <Tooltip />
                      <Bar dataKey="contacts" fill="#3b82f6" />
                    </RechartsBarChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
              <CardFooter className="border-t pt-4">
                <div className="space-y-2 w-full">
                  <h4 className="font-medium">AI Recommendation</h4>
                  <div className="p-3 bg-yellow-50 text-yellow-700 rounded-md dark:bg-yellow-900/30 dark:text-yellow-300">
                    <p className="text-sm">
                      You have 5 high-value contacts who are currently inactive. Consider scheduling follow-ups with
                      these connections to revitalize these relationships.
                    </p>
                  </div>
                </div>
              </CardFooter>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="platforms" className="space-y-6">
          <div className="grid gap-6 md:grid-cols-2">
            <Card className="border-primary/20">
              <CardHeader>
                <CardTitle className="text-lg">Platform Distribution</CardTitle>
                <CardDescription>Where your connections are coming from</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-80">
                  <ResponsiveContainer width="100%" height="100%">
                    <RechartsPieChart>
                      <Pie
                        data={platformDistributionData}
                        cx="50%"
                        cy="50%"
                        innerRadius={60}
                        outerRadius={100}
                        paddingAngle={5}
                        dataKey="value"
                        label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                      >
                        {platformDistributionData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={entry.color} />
                        ))}
                      </Pie>
                      <Tooltip />
                      <Legend />
                    </RechartsPieChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>

            <Card className="border-primary/20">
              <CardHeader>
                <CardTitle className="text-lg">Platform Engagement</CardTitle>
                <CardDescription>Your activity across different platforms</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-80">
                  <ResponsiveContainer width="100%" height="100%">
                    <RechartsBarChart
                      data={[
                        { platform: "LinkedIn", messages: 28, meetings: 5 },
                        { platform: "Facebook", messages: 15, meetings: 2 },
                        { platform: "Direct", messages: 10, meetings: 8 },
                      ]}
                    >
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="platform" />
                      <YAxis />
                      <Tooltip />
                      <Legend />
                      <Bar dataKey="messages" fill="#0077B5" name="Messages" />
                      <Bar dataKey="meetings" fill="#eab308" name="Meetings" />
                    </RechartsBarChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
              <CardFooter className="border-t pt-4">
                <div className="space-y-2 w-full">
                  <h4 className="font-medium">Platform Strategy</h4>
                  <div className="p-3 bg-blue-50 text-blue-700 rounded-md dark:bg-blue-900/30 dark:text-blue-300">
                    <p className="text-sm">
                      LinkedIn is your most active platform. Consider increasing your Facebook engagement to better
                      balance your professional and personal networking.
                    </p>
                  </div>
                </div>
              </CardFooter>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
}

