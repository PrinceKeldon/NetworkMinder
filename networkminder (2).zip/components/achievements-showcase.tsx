"use client"

import { useState } from "react"
import {
  Award,
  Trophy,
  Star,
  Zap,
  Users,
  MessageCircle,
  Calendar,
  Share2,
  ChevronRight,
  ChevronLeft,
  Lock,
  Check,
} from "lucide-react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { SocialShareDialog } from "@/components/social-share-dialog"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"

// Mock achievements data
const achievements = [
  {
    id: 1,
    name: "Network Builder",
    description: "Add 10 contacts to your network",
    icon: <Users className="h-6 w-6" />,
    progress: 100,
    completed: true,
    date: "2023-11-15",
    reward: "Bronze Badge",
    category: "connections",
  },
  {
    id: 2,
    name: "Follow-up Master",
    description: "Complete 15 follow-ups on time",
    icon: <Calendar className="h-6 w-6" />,
    progress: 100,
    completed: true,
    date: "2023-12-05",
    reward: "Silver Badge",
    category: "engagement",
  },
  {
    id: 3,
    name: "Conversation Starter",
    description: "Send 20 messages to your contacts",
    icon: <MessageCircle className="h-6 w-6" />,
    progress: 80,
    completed: false,
    target: 20,
    current: 16,
    reward: "5 AI Credits",
    category: "engagement",
  },
  {
    id: 4,
    name: "Social Connector",
    description: "Connect both LinkedIn and Facebook accounts",
    icon: <Zap className="h-6 w-6" />,
    progress: 100,
    completed: true,
    date: "2023-10-20",
    reward: "Profile Boost",
    category: "integration",
  },
  {
    id: 5,
    name: "Networking Pro",
    description: "Add 25 contacts to your network",
    icon: <Users className="h-6 w-6" />,
    progress: 72,
    completed: false,
    target: 25,
    current: 18,
    reward: "Gold Badge",
    category: "connections",
  },
  {
    id: 6,
    name: "Event Networker",
    description: "Add 5 contacts from a single event",
    icon: <Users className="h-6 w-6" />,
    progress: 60,
    completed: false,
    target: 5,
    current: 3,
    reward: "Event Badge",
    category: "connections",
  },
  {
    id: 7,
    name: "Consistent Networker",
    description: "Log in for 7 consecutive days",
    icon: <Zap className="h-6 w-6" />,
    progress: 100,
    completed: true,
    date: "2023-12-10",
    reward: "Streak Badge",
    category: "engagement",
  },
  {
    id: 8,
    name: "Referral Champion",
    description: "Invite 5 friends who join NetworkMinder",
    icon: <Share2 className="h-6 w-6" />,
    progress: 40,
    completed: false,
    target: 5,
    current: 2,
    reward: "Premium Week",
    category: "referrals",
  },
]

// Mock leaderboard data
const leaderboardData = [
  { id: 1, name: "Alex Johnson", image: "/placeholder.svg?height=40&width=40", points: 1250, position: 1 },
  { id: 2, name: "Sam Rivera", image: "/placeholder.svg?height=40&width=40", points: 980, position: 2 },
  { id: 3, name: "Jordan Lee", image: "/placeholder.svg?height=40&width=40", points: 840, position: 3 },
  { id: 4, name: "Taylor Wilson", image: "/placeholder.svg?height=40&width=40", points: 720, position: 4 },
  { id: 5, name: "Casey Morgan", image: "/placeholder.svg?height=40&width=40", points: 650, position: 5 },
  // Current user
  { id: 6, name: "You", image: "/placeholder.svg?height=40&width=40", points: 580, position: 6, isCurrentUser: true },
  // More users
  { id: 7, name: "Jamie Rivera", image: "/placeholder.svg?height=40&width=40", points: 520, position: 7 },
  { id: 8, name: "Riley Adams", image: "/placeholder.svg?height=40&width=40", points: 480, position: 8 },
]

export function AchievementsShowcase() {
  const [activeTab, setActiveTab] = useState("achievements")
  const [selectedCategory, setSelectedCategory] = useState("all")
  const [featuredAchievement, setFeaturedAchievement] = useState(achievements[0])

  // Filter achievements by category
  const filteredAchievements =
    selectedCategory === "all"
      ? achievements
      : achievements.filter((achievement) => achievement.category === selectedCategory)

  // Calculate stats
  const completedCount = achievements.filter((a) => a.completed).length
  const totalCount = achievements.length
  const completionPercentage = Math.round((completedCount / totalCount) * 100)

  // Calculate points (mock calculation)
  const calculatePoints = () => {
    return achievements.reduce((total, achievement) => {
      if (achievement.completed) {
        return total + 100
      } else {
        return total + Math.round(achievement.progress)
      }
    }, 0)
  }

  const totalPoints = calculatePoints()

  // Navigate through featured achievements
  const navigateFeatured = (direction: "next" | "prev") => {
    const currentIndex = achievements.findIndex((a) => a.id === featuredAchievement.id)
    let newIndex

    if (direction === "next") {
      newIndex = (currentIndex + 1) % achievements.length
    } else {
      newIndex = (currentIndex - 1 + achievements.length) % achievements.length
    }

    setFeaturedAchievement(achievements[newIndex])
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h2 className="text-2xl font-bold">Achievements & Leaderboard</h2>
          <p className="text-muted-foreground">Track your progress and compete with other networkers</p>
        </div>
      </div>

      <div className="grid gap-6 md:grid-cols-3">
        <Card className="border-primary/20 md:col-span-2">
          <CardHeader className="pb-2">
            <div className="flex justify-between items-center">
              <div className="flex items-center gap-2">
                <Trophy className="h-5 w-5 text-highlight" />
                <CardTitle>Featured Achievement</CardTitle>
              </div>
              <div className="flex gap-1">
                <Button variant="ghost" size="icon" onClick={() => navigateFeatured("prev")}>
                  <ChevronLeft className="h-4 w-4" />
                </Button>
                <Button variant="ghost" size="icon" onClick={() => navigateFeatured("next")}>
                  <ChevronRight className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </CardHeader>
          <CardContent className="pt-2">
            <div className="flex flex-col md:flex-row gap-4 items-center">
              <div
                className={`w-20 h-20 rounded-full flex items-center justify-center ${
                  featuredAchievement.completed ? "bg-highlight/20 text-highlight" : "bg-muted text-muted-foreground"
                }`}
              >
                {featuredAchievement.icon}
              </div>
              <div className="flex-1 text-center md:text-left">
                <div className="flex flex-col md:flex-row md:items-center gap-2 mb-2">
                  <h3 className="text-xl font-bold">{featuredAchievement.name}</h3>
                  {featuredAchievement.completed ? (
                    <Badge className="bg-green-100 text-green-700 dark:bg-green-700/20 dark:text-green-400 self-center md:self-auto">
                      Completed
                    </Badge>
                  ) : (
                    <Badge className="bg-blue-100 text-blue-700 dark:bg-blue-700/20 dark:text-blue-400 self-center md:self-auto">
                      In Progress
                    </Badge>
                  )}
                </div>
                <p className="text-muted-foreground mb-3">{featuredAchievement.description}</p>
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span>Progress</span>
                    <span>{featuredAchievement.progress}%</span>
                  </div>
                  <Progress value={featuredAchievement.progress} className="h-2" />
                  {!featuredAchievement.completed && featuredAchievement.current !== undefined && (
                    <p className="text-sm text-muted-foreground">
                      {featuredAchievement.current} / {featuredAchievement.target} completed
                    </p>
                  )}
                </div>
              </div>
              <div className="text-center md:text-right">
                <div className="mb-2">
                  <span className="text-sm text-muted-foreground">Reward</span>
                  <div className="font-medium">{featuredAchievement.reward}</div>
                </div>
                {featuredAchievement.completed ? (
                  <SocialShareDialog
                    trigger={
                      <Button size="sm">
                        <Share2 className="h-4 w-4 mr-2" />
                        Share
                      </Button>
                    }
                    defaultMessage={`I just earned the "${featuredAchievement.name}" achievement on NetworkMinder!`}
                  />
                ) : (
                  <Button size="sm" variant="outline">
                    View Details
                  </Button>
                )}
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-primary/20">
          <CardHeader className="pb-2">
            <CardTitle>Your Progress</CardTitle>
          </CardHeader>
          <CardContent className="pt-2">
            <div className="space-y-4">
              <div className="text-center">
                <div className="text-3xl font-bold">{totalPoints}</div>
                <p className="text-sm text-muted-foreground">Total Points</p>
              </div>

              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span>Achievements</span>
                  <span>
                    {completedCount} / {totalCount}
                  </span>
                </div>
                <Progress value={completionPercentage} className="h-2" />
                <p className="text-sm text-muted-foreground text-center">{completionPercentage}% Complete</p>
              </div>

              <div className="pt-2 flex justify-center">
                <Badge className="bg-highlight/20 text-highlight px-3 py-1 text-sm">
                  <Star className="h-3 w-3 mr-1" />
                  Level 3 Networker
                </Badge>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="achievements">
            <Award className="h-4 w-4 mr-2" />
            Achievements
          </TabsTrigger>
          <TabsTrigger value="leaderboard">
            <Trophy className="h-4 w-4 mr-2" />
            Leaderboard
          </TabsTrigger>
        </TabsList>

        <TabsContent value="achievements" className="space-y-4">
          <div className="flex flex-wrap gap-2">
            <Badge
              variant={selectedCategory === "all" ? "default" : "outline"}
              className="cursor-pointer"
              onClick={() => setSelectedCategory("all")}
            >
              All
            </Badge>
            <Badge
              variant={selectedCategory === "connections" ? "default" : "outline"}
              className="cursor-pointer"
              onClick={() => setSelectedCategory("connections")}
            >
              Connections
            </Badge>
            <Badge
              variant={selectedCategory === "engagement" ? "default" : "outline"}
              className="cursor-pointer"
              onClick={() => setSelectedCategory("engagement")}
            >
              Engagement
            </Badge>
            <Badge
              variant={selectedCategory === "integration" ? "default" : "outline"}
              className="cursor-pointer"
              onClick={() => setSelectedCategory("integration")}
            >
              Integration
            </Badge>
            <Badge
              variant={selectedCategory === "referrals" ? "default" : "outline"}
              className="cursor-pointer"
              onClick={() => setSelectedCategory("referrals")}
            >
              Referrals
            </Badge>
          </div>

          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {filteredAchievements.map((achievement) => (
              <Card
                key={achievement.id}
                className={`border-2 ${achievement.completed ? "border-highlight/50" : "border-muted"}`}
              >
                <CardContent className="pt-6">
                  <div className="flex items-start gap-4">
                    <div
                      className={`w-12 h-12 rounded-full flex items-center justify-center flex-shrink-0 ${
                        achievement.completed ? "bg-highlight/20 text-highlight" : "bg-muted text-muted-foreground"
                      }`}
                    >
                      {achievement.icon}
                    </div>
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <h3 className="font-medium">{achievement.name}</h3>
                        {achievement.completed && (
                          <Badge
                            variant="outline"
                            className="bg-green-100 text-green-700 dark:bg-green-700/20 dark:text-green-400"
                          >
                            <Check className="h-3 w-3 mr-1" />
                          </Badge>
                        )}
                      </div>
                      <p className="text-sm text-muted-foreground">{achievement.description}</p>
                      <div className="pt-2 space-y-1">
                        <Progress value={achievement.progress} className="h-1.5" />
                        <div className="flex justify-between text-xs text-muted-foreground">
                          <span>{achievement.progress}%</span>
                          {achievement.completed ? (
                            <span>Completed {achievement.date}</span>
                          ) : (
                            <span>
                              {achievement.current} / {achievement.target}
                            </span>
                          )}
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}

            {/* Locked achievements */}
            <Card className="border-dashed border-muted bg-muted/50">
              <CardContent className="pt-6">
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 rounded-full flex items-center justify-center flex-shrink-0 bg-muted/70 text-muted-foreground">
                    <Lock className="h-6 w-6" />
                  </div>
                  <div className="space-y-1">
                    <h3 className="font-medium">Networking Expert</h3>
                    <p className="text-sm text-muted-foreground">Reach 50 connections to unlock</p>
                    <div className="pt-2">
                      <Button variant="outline" size="sm" className="w-full">
                        View Requirements
                      </Button>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="leaderboard" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Top Networkers</CardTitle>
              <CardDescription>See how you rank against other NetworkMinder users</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {leaderboardData.map((user) => (
                  <div
                    key={user.id}
                    className={`flex items-center justify-between p-3 rounded-md ${
                      user.isCurrentUser
                        ? "bg-highlight/10 border border-highlight/30"
                        : user.position <= 3
                          ? "bg-muted/50"
                          : ""
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <div
                        className={`w-8 h-8 rounded-full flex items-center justify-center font-bold ${
                          user.position === 1
                            ? "bg-yellow-100 text-yellow-700 dark:bg-yellow-700/30 dark:text-yellow-300"
                            : user.position === 2
                              ? "bg-gray-100 text-gray-700 dark:bg-gray-700/30 dark:text-gray-300"
                              : user.position === 3
                                ? "bg-amber-100 text-amber-700 dark:bg-amber-700/30 dark:text-amber-300"
                                : "bg-muted text-muted-foreground"
                        }`}
                      >
                        {user.position}
                      </div>
                      <Avatar className="h-10 w-10">
                        <AvatarImage src={user.image} alt={user.name} />
                        <AvatarFallback>{user.name.charAt(0)}</AvatarFallback>
                      </Avatar>
                      <div>
                        <div className="font-medium">
                          {user.name} {user.isCurrentUser && "(You)"}
                        </div>
                        {user.position === 1 && (
                          <Badge className="bg-yellow-100 text-yellow-700 dark:bg-yellow-700/30 dark:text-yellow-300">
                            <Trophy className="h-3 w-3 mr-1" />
                            Top Networker
                          </Badge>
                        )}
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="font-bold">{user.points}</div>
                      <div className="text-xs text-muted-foreground">points</div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
            <CardFooter className="border-t pt-4 flex justify-between">
              <p className="text-sm text-muted-foreground">Updated daily at midnight</p>
              <Button variant="outline" size="sm">
                View Full Rankings
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}

