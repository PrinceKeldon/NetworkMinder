"use client"

import { useState } from "react"
import {
  Share2,
  Gift,
  Award,
  Trophy,
  Star,
  Users,
  ArrowRight,
  Check,
  Copy,
  Twitter,
  Facebook,
  Linkedin,
  Mail,
  Sparkles,
} from "lucide-react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Progress } from "@/components/ui/progress"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { useToast } from "@/hooks/use-toast"

export function GamifiedReferrals() {
  const [activeTab, setActiveTab] = useState("invite")
  const [copied, setCopied] = useState(false)
  const { toast } = useToast()

  // Mock referral data
  const referralCode = "NETWORK25"
  const referralLink = "https://networkminder.app/ref/NETWORK25"
  const referralStats = {
    invited: 8,
    joined: 3,
    target: 10,
    level: 2,
    points: 350,
    nextLevelPoints: 500,
    rewards: [
      { level: 1, reward: "1 month free premium", achieved: true, points: 100 },
      { level: 2, reward: "Access to exclusive events", achieved: true, points: 250 },
      { level: 3, reward: "Annual premium membership", achieved: false, points: 500 },
      { level: 4, reward: "VIP networking event access", achieved: false, points: 750 },
      { level: 5, reward: "1-on-1 networking coaching", achieved: false, points: 1000 },
    ],
    invitedFriends: [
      { name: "Alex Johnson", image: "/placeholder.svg?height=40&width=40", status: "joined", date: "Mar 10, 2025" },
      { name: "Sam Rivera", image: "/placeholder.svg?height=40&width=40", status: "joined", date: "Mar 5, 2025" },
      { name: "Jordan Lee", image: "/placeholder.svg?height=40&width=40", status: "joined", date: "Feb 28, 2025" },
      { name: "Taylor Wilson", image: "/placeholder.svg?height=40&width=40", status: "pending", date: "Mar 12, 2025" },
      { name: "Casey Morgan", image: "/placeholder.svg?height=40&width=40", status: "pending", date: "Mar 11, 2025" },
    ],
  }

  const copyToClipboard = () => {
    navigator.clipboard.writeText(referralLink)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)

    toast({
      title: "Copied to Clipboard",
      description: "Share link and code copied to clipboard",
    })
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h2 className="text-2xl font-bold">Referral Program</h2>
          <p className="text-muted-foreground">Invite friends and earn exclusive rewards</p>
        </div>
      </div>

      <div className="grid gap-6 md:grid-cols-3">
        <Card className="border-primary/20 md:col-span-2">
          <CardHeader className="pb-2">
            <div className="flex justify-between items-center">
              <CardTitle className="flex items-center">
                <Trophy className="h-5 w-5 text-highlight mr-2" />
                Referral Progress
              </CardTitle>
              <Badge className="bg-highlight/20 text-highlight">Level {referralStats.level}</Badge>
            </div>
          </CardHeader>
          <CardContent className="pt-2">
            <div className="space-y-4">
              <div className="flex flex-col sm:flex-row gap-4 items-center">
                <div className="w-24 h-24 rounded-full bg-highlight/20 flex items-center justify-center">
                  <div className="w-20 h-20 rounded-full bg-highlight/30 flex items-center justify-center">
                    <div className="w-16 h-16 rounded-full bg-highlight flex items-center justify-center text-white font-bold text-xl">
                      {referralStats.joined}/{referralStats.target}
                    </div>
                  </div>
                </div>

                <div className="flex-1 space-y-2 text-center sm:text-left">
                  <h3 className="text-lg font-bold">{referralStats.points} Points Earned</h3>
                  <p className="text-sm text-muted-foreground">
                    {referralStats.nextLevelPoints - referralStats.points} points until Level {referralStats.level + 1}
                  </p>
                  <div className="space-y-1">
                    <Progress value={(referralStats.points / referralStats.nextLevelPoints) * 100} className="h-2" />
                    <div className="flex justify-between text-xs text-muted-foreground">
                      <span>Level {referralStats.level}</span>
                      <span>Level {referralStats.level + 1}</span>
                    </div>
                  </div>
                </div>

                <div className="text-center sm:text-right">
                  <div className="mb-2">
                    <span className="text-sm text-muted-foreground">Next Reward</span>
                    <div className="font-medium">Annual Premium</div>
                  </div>
                  <Button size="sm" className="bg-highlight hover:bg-highlight/90 text-white">
                    <Share2 className="h-4 w-4 mr-2" />
                    Invite More
                  </Button>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-4">
                {referralStats.rewards.slice(0, 3).map((reward, index) => (
                  <Card key={index} className={`border ${reward.achieved ? "border-green-500" : "border-muted"}`}>
                    <CardContent className="p-4">
                      <div className="flex items-center justify-between mb-2">
                        <Badge className={reward.achieved ? "bg-green-100 text-green-700" : "bg-muted"}>
                          Level {index + 1}
                        </Badge>
                        {reward.achieved && <Check className="h-4 w-4 text-green-500" />}
                      </div>
                      <div className="space-y-1">
                        <div className="font-medium">{reward.reward}</div>
                        <div className="text-xs text-muted-foreground">{reward.points} points</div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-primary/20">
          <CardHeader className="pb-2">
            <CardTitle>Your Referral Link</CardTitle>
          </CardHeader>
          <CardContent className="pt-2 space-y-4">
            <div className="space-y-2">
              <div className="flex space-x-2">
                <Input value={referralLink} readOnly className="font-mono text-sm" />
                <Button variant="outline" size="icon" onClick={copyToClipboard} className="flex-shrink-0">
                  {copied ? <Check className="h-4 w-4 text-green-500" /> : <Copy className="h-4 w-4" />}
                  <span className="sr-only">{copied ? "Copied" : "Copy"}</span>
                </Button>
              </div>
              <div className="flex items-center justify-between">
                <div className="text-sm text-muted-foreground">
                  Referral Code: <span className="font-mono font-medium">{referralCode}</span>
                </div>
                <Button variant="ghost" size="sm" onClick={copyToClipboard}>
                  Copy
                </Button>
              </div>
            </div>

            <div className="pt-2">
              <h4 className="text-sm font-medium mb-2">Share via</h4>
              <div className="grid grid-cols-2 gap-2">
                <Button variant="outline" size="sm" className="flex items-center">
                  <Linkedin className="h-4 w-4 mr-2 text-[#0077B5]" />
                  LinkedIn
                </Button>
                <Button variant="outline" size="sm" className="flex items-center">
                  <Facebook className="h-4 w-4 mr-2 text-[#1877F2]" />
                  Facebook
                </Button>
                <Button variant="outline" size="sm" className="flex items-center">
                  <Twitter className="h-4 w-4 mr-2 text-[#1DA1F2]" />
                  Twitter
                </Button>
                <Button variant="outline" size="sm" className="flex items-center">
                  <Mail className="h-4 w-4 mr-2 text-primary" />
                  Email
                </Button>
              </div>
            </div>

            <div className="pt-4 mt-2 border-t">
              <div className="flex items-center justify-between mb-2">
                <h4 className="text-sm font-medium">Bonus Points</h4>
                <Badge className="bg-highlight/20 text-highlight">+50 points</Badge>
              </div>
              <p className="text-xs text-muted-foreground mb-2">
                Share your referral milestone on social media to earn bonus points!
              </p>
              <Button size="sm" className="w-full">
                <Sparkles className="h-4 w-4 mr-2" />
                Share Achievement
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="invite">
            <Share2 className="h-4 w-4 mr-2" />
            Invite Friends
          </TabsTrigger>
          <TabsTrigger value="rewards">
            <Gift className="h-4 w-4 mr-2" />
            Rewards
          </TabsTrigger>
        </TabsList>

        <TabsContent value="invite" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Your Invites</CardTitle>
              <CardDescription>Track the status of your referral invitations</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {referralStats.invitedFriends.map((friend, index) => (
                  <div key={index} className="flex items-center justify-between p-3 rounded-md border">
                    <div className="flex items-center gap-3">
                      <Avatar className="h-10 w-10">
                        <AvatarImage src={friend.image} alt={friend.name} />
                        <AvatarFallback>{friend.name.charAt(0)}</AvatarFallback>
                      </Avatar>
                      <div>
                        <div className="font-medium">{friend.name}</div>
                        <div className="text-xs text-muted-foreground">Invited: {friend.date}</div>
                      </div>
                    </div>
                    <div>
                      {friend.status === "joined" ? (
                        <Badge className="bg-green-100 text-green-700">
                          <Check className="h-3 w-3 mr-1" />
                          Joined
                        </Badge>
                      ) : (
                        <Badge variant="outline" className="bg-yellow-100 text-yellow-700">
                          Pending
                        </Badge>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
            <CardFooter className="border-t pt-4 flex justify-between">
              <p className="text-sm text-muted-foreground">
                {referralStats.joined} of {referralStats.invited} invites accepted
              </p>
              <Button size="sm">Send Reminder</Button>
            </CardFooter>
          </Card>

          <Card className="border-dashed">
            <CardContent className="pt-6 pb-6">
              <div className="flex flex-col sm:flex-row gap-6 items-center">
                <div className="w-16 h-16 rounded-full bg-highlight/20 flex items-center justify-center">
                  <Users className="h-8 w-8 text-highlight" />
                </div>
                <div className="flex-1 text-center sm:text-left">
                  <h3 className="font-bold text-lg mb-1">Invite your team or company</h3>
                  <p className="text-sm text-muted-foreground mb-4">
                    Get special bonuses when you invite 5+ colleagues from the same organization
                  </p>
                  <Button>
                    Team Invites
                    <ArrowRight className="ml-2 h-4 w-4" />
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="rewards" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Reward Levels</CardTitle>
              <CardDescription>Unlock these rewards as you refer more friends</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {referralStats.rewards.map((reward, index) => (
                  <div
                    key={index}
                    className={`p-4 rounded-md border ${
                      reward.achieved ? "bg-green-500/10 border-green-500/20" : "bg-muted/30 border-muted-foreground/20"
                    }`}
                  >
                    <div className="flex justify-between items-center">
                      <div className="flex items-center">
                        <div
                          className={`w-10 h-10 rounded-full flex items-center justify-center mr-3 ${
                            reward.achieved ? "bg-green-100 text-green-700" : "bg-muted text-muted-foreground"
                          }`}
                        >
                          <Award className="h-5 w-5" />
                        </div>
                        <div>
                          <div className="flex items-center">
                            <h4 className="font-medium">Level {index + 1}</h4>
                            {reward.achieved && (
                              <Badge className="ml-2 bg-green-100 text-green-700">
                                <Check className="h-3 w-3 mr-1" />
                                Unlocked
                              </Badge>
                            )}
                          </div>
                          <p className="text-sm">{reward.reward}</p>
                        </div>
                      </div>
                      <Badge
                        variant="outline"
                        className={
                          reward.achieved
                            ? "bg-green-500/20 border-green-500/30 text-green-700"
                            : "bg-muted-foreground/10"
                        }
                      >
                        {reward.points} points
                      </Badge>
                    </div>

                    {!reward.achieved && (
                      <div className="mt-3 pt-3 border-t border-dashed">
                        <div className="flex justify-between text-sm mb-1">
                          <span>Progress</span>
                          <span>{Math.round((referralStats.points / reward.points) * 100)}%</span>
                        </div>
                        <Progress value={(referralStats.points / reward.points) * 100} className="h-1.5" />
                        <p className="text-xs text-muted-foreground mt-2">
                          {reward.points - referralStats.points} more points needed
                        </p>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          <Card className="border-highlight/30 bg-highlight/5">
            <CardContent className="pt-6 pb-6">
              <div className="flex flex-col sm:flex-row gap-6 items-center">
                <div className="w-16 h-16 rounded-full bg-highlight/30 flex items-center justify-center">
                  <Star className="h-8 w-8 text-highlight" />
                </div>
                <div className="flex-1 text-center sm:text-left">
                  <h3 className="font-bold text-lg mb-1">VIP Referral Program</h3>
                  <p className="text-sm text-muted-foreground mb-4">
                    Refer 10+ friends to join our exclusive VIP program with special perks and rewards
                  </p>
                  <Button className="bg-highlight hover:bg-highlight/90 text-white">
                    Learn More
                    <ArrowRight className="ml-2 h-4 w-4" />
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}

