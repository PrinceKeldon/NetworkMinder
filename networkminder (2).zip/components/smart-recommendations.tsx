"use client"

import { useState } from "react"
import {
  Users,
  UserPlus,
  Sparkles,
  Filter,
  ArrowRight,
  MapPin,
  GraduationCap,
  Linkedin,
  Facebook,
  Calendar,
} from "lucide-react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Progress } from "@/components/ui/progress"

// Mock data for recommended connections
const recommendedConnections = [
  {
    id: 1,
    name: "Emily Chen",
    role: "Product Manager at TechCorp",
    image: "/placeholder.svg?height=100&width=100",
    mutualConnections: 5,
    matchScore: 92,
    tags: ["Product", "SaaS", "UX"],
    source: "linkedin",
    reason: "Based on your interest in product management and tech",
    location: "San Francisco, CA",
    education: "Stanford University",
  },
  {
    id: 2,
    name: "Marcus Johnson",
    role: "Marketing Director at GrowthLabs",
    image: "/placeholder.svg?height=100&width=100",
    mutualConnections: 3,
    matchScore: 87,
    tags: ["Marketing", "Growth", "Analytics"],
    source: "linkedin",
    reason: "Connected with 3 people in your network recently",
    location: "New York, NY",
    education: "NYU Stern",
  },
  {
    id: 3,
    name: "Sophia Rodriguez",
    role: "UX Designer at DesignHub",
    image: "/placeholder.svg?height=100&width=100",
    mutualConnections: 2,
    matchScore: 85,
    tags: ["Design", "UX/UI", "Creative"],
    source: "facebook",
    reason: "Attended the same Design Conference as you",
    location: "Austin, TX",
    education: "RISD",
  },
  {
    id: 4,
    name: "David Kim",
    role: "Software Engineer at InnovateTech",
    image: "/placeholder.svg?height=100&width=100",
    mutualConnections: 4,
    matchScore: 83,
    tags: ["Engineering", "AI", "Cloud"],
    source: "linkedin",
    reason: "Works in AI, which you've shown interest in",
    location: "Seattle, WA",
    education: "University of Washington",
  },
  {
    id: 5,
    name: "Olivia Taylor",
    role: "Startup Founder at EcoSolutions",
    image: "/placeholder.svg?height=100&width=100",
    mutualConnections: 1,
    matchScore: 80,
    tags: ["Startup", "Sustainability", "Leadership"],
    source: "facebook",
    reason: "Friend of Alex Johnson, shares your interest in sustainability",
    location: "Portland, OR",
    education: "UC Berkeley",
  },
]

// Mock data for networking opportunities
const networkingOpportunities = [
  {
    id: 1,
    title: "Tech Innovators Meetup",
    date: "Mar 25, 2025",
    location: "Downtown Convention Center",
    attendees: 120,
    relevanceScore: 95,
    tags: ["Technology", "Innovation", "Networking"],
    description: "Connect with tech professionals and innovators in your area.",
    potentialConnections: 15,
  },
  {
    id: 2,
    title: "Women in Business Conference",
    date: "Apr 10, 2025",
    location: "Grand Hotel & Conference Center",
    attendees: 250,
    relevanceScore: 88,
    tags: ["Business", "Leadership", "Women"],
    description: "Annual conference for women business leaders and entrepreneurs.",
    potentialConnections: 22,
  },
  {
    id: 3,
    title: "Startup Pitch Night",
    date: "Apr 18, 2025",
    location: "Innovation Hub",
    attendees: 85,
    relevanceScore: 82,
    tags: ["Startup", "Investing", "Pitch"],
    description: "Watch startups pitch their ideas and network with founders and investors.",
    potentialConnections: 10,
  },
]

export function SmartRecommendations() {
  const [activeTab, setActiveTab] = useState("people")
  const [industryFilter, setIndustryFilter] = useState("all")
  const [locationFilter, setLocationFilter] = useState("all")

  // Filter recommendations based on selected filters
  const filteredRecommendations = recommendedConnections.filter((person) => {
    if (industryFilter !== "all") {
      const personIndustries = person.tags.map((tag) => tag.toLowerCase())
      if (!personIndustries.includes(industryFilter.toLowerCase())) {
        return false
      }
    }

    if (locationFilter !== "all" && !person.location.includes(locationFilter)) {
      return false
    }

    return true
  })

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h2 className="text-2xl font-bold">Smart Recommendations</h2>
          <p className="text-muted-foreground">AI-powered suggestions to grow your network</p>
        </div>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="people">
            <Users className="h-4 w-4 mr-2" />
            People
          </TabsTrigger>
          <TabsTrigger value="events">
            <Calendar className="h-4 w-4 mr-2" />
            Events
          </TabsTrigger>
        </TabsList>

        {/* PEOPLE TAB CONTENT */}
        <TabsContent value="people" className="space-y-4">
          <div className="flex flex-col sm:flex-row gap-4 justify-between">
            <div className="flex flex-wrap gap-2 items-center">
              <span className="text-sm font-medium">Filter by:</span>
              <Select value={industryFilter} onValueChange={setIndustryFilter}>
                <SelectTrigger className="w-[150px]">
                  <SelectValue placeholder="Industry" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Industries</SelectItem>
                  <SelectItem value="product">Product</SelectItem>
                  <SelectItem value="marketing">Marketing</SelectItem>
                  <SelectItem value="design">Design</SelectItem>
                  <SelectItem value="engineering">Engineering</SelectItem>
                  <SelectItem value="startup">Startup</SelectItem>
                </SelectContent>
              </Select>

              <Select value={locationFilter} onValueChange={setLocationFilter}>
                <SelectTrigger className="w-[150px]">
                  <SelectValue placeholder="Location" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Locations</SelectItem>
                  <SelectItem value="San Francisco">San Francisco</SelectItem>
                  <SelectItem value="New York">New York</SelectItem>
                  <SelectItem value="Austin">Austin</SelectItem>
                  <SelectItem value="Seattle">Seattle</SelectItem>
                  <SelectItem value="Portland">Portland</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <Button variant="outline" size="sm" className="flex-shrink-0">
              <Filter className="h-4 w-4 mr-2" />
              More Filters
            </Button>
          </div>

          <div className="space-y-4">
            {filteredRecommendations.length === 0 ? (
              <Card className="border-dashed">
                <CardContent className="pt-6 pb-6 text-center">
                  <div className="mx-auto w-12 h-12 rounded-full bg-muted flex items-center justify-center mb-4">
                    <Users className="h-6 w-6 text-muted-foreground" />
                  </div>
                  <h3 className="font-medium mb-2">No matches found</h3>
                  <p className="text-sm text-muted-foreground mb-4">
                    Try adjusting your filters to see more recommendations
                  </p>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => {
                      setIndustryFilter("all")
                      setLocationFilter("all")
                    }}
                  >
                    Reset Filters
                  </Button>
                </CardContent>
              </Card>
            ) : (
              filteredRecommendations.map((person) => (
                <Card key={person.id} className="overflow-hidden">
                  <div className="flex flex-col sm:flex-row">
                    <div className="sm:w-1/3 p-6 bg-muted/30 flex flex-col items-center justify-center text-center">
                      <Avatar className="h-24 w-24 mb-4">
                        <AvatarImage src={person.image} alt={person.name} />
                        <AvatarFallback>
                          {person.name
                            .split(" ")
                            .map((n) => n[0])
                            .join("")}
                        </AvatarFallback>
                      </Avatar>
                      <h3 className="font-bold text-lg">{person.name}</h3>
                      <p className="text-sm text-muted-foreground mb-2">{person.role}</p>
                      <div className="flex items-center justify-center mb-3">
                        {person.source === "linkedin" ? (
                          <Badge variant="outline" className="bg-[#0077B5]/10 border-[#0077B5]/20 text-[#0077B5]">
                            <Linkedin className="h-3 w-3 mr-1" />
                            LinkedIn
                          </Badge>
                        ) : (
                          <Badge variant="outline" className="bg-[#1877F2]/10 border-[#1877F2]/20 text-[#1877F2]">
                            <Facebook className="h-3 w-3 mr-1" />
                            Facebook
                          </Badge>
                        )}
                      </div>
                      <div className="flex flex-wrap gap-1 justify-center">
                        {person.tags.map((tag, index) => (
                          <Badge key={index} variant="outline" className="bg-primary/5 text-primary">
                            {tag}
                          </Badge>
                        ))}
                      </div>
                    </div>

                    <div className="sm:w-2/3 p-6">
                      <div className="mb-4">
                        <div className="flex justify-between items-center mb-2">
                          <h4 className="font-medium">Match Score</h4>
                          <Badge
                            className={`${
                              person.matchScore >= 90
                                ? "bg-green-100 text-green-700 dark:bg-green-700/20 dark:text-green-400"
                                : person.matchScore >= 80
                                  ? "bg-blue-100 text-blue-700 dark:bg-blue-700/20 dark:text-blue-400"
                                  : "bg-yellow-100 text-yellow-700 dark:bg-yellow-700/20 dark:text-yellow-400"
                            }`}
                          >
                            {person.matchScore}%
                          </Badge>
                        </div>
                        <Progress value={person.matchScore} className="h-2" />
                      </div>

                      <div className="space-y-3 mb-4">
                        <div className="flex items-start gap-2">
                          <Sparkles className="h-4 w-4 text-primary mt-0.5" />
                          <div className="flex-1">
                            <h4 className="font-medium text-sm">Why we recommend</h4>
                            <p className="text-sm text-muted-foreground">{person.reason}</p>
                          </div>
                        </div>

                        <div className="flex items-start gap-2">
                          <Users className="h-4 w-4 text-primary mt-0.5" />
                          <div>
                            <h4 className="font-medium text-sm">Mutual Connections</h4>
                            <p className="text-sm text-muted-foreground">
                              {person.mutualConnections} shared connections
                            </p>
                          </div>
                        </div>

                        <div className="flex items-start gap-2">
                          <MapPin className="h-4 w-4 text-primary mt-0.5" />
                          <div>
                            <h4 className="font-medium text-sm">Location</h4>
                            <p className="text-sm text-muted-foreground">{person.location}</p>
                          </div>
                        </div>

                        <div className="flex items-start gap-2">
                          <GraduationCap className="h-4 w-4 text-primary mt-0.5" />
                          <div>
                            <h4 className="font-medium text-sm">Education</h4>
                            <p className="text-sm text-muted-foreground">{person.education}</p>
                          </div>
                        </div>
                      </div>

                      <div className="flex flex-col sm:flex-row gap-2 sm:justify-end">
                        <Button variant="outline">View Profile</Button>
                        <Button>
                          <UserPlus className="h-4 w-4 mr-2" />
                          Connect
                        </Button>
                      </div>
                    </div>
                  </div>
                </Card>
              ))
            )}
          </div>
        </TabsContent>

        {/* EVENTS TAB CONTENT */}
        <TabsContent value="events" className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {networkingOpportunities.map((event) => (
              <Card key={event.id} className="overflow-hidden">
                <div className="relative h-32 w-full bg-muted">
                  <div className="absolute inset-0 bg-gradient-to-br from-primary/20 to-highlight/20 flex items-center justify-center">
                    <Calendar className="h-12 w-12 text-primary/40" />
                  </div>
                  <div className="absolute top-2 right-2">
                    <Badge
                      className={`${
                        event.relevanceScore >= 90
                          ? "bg-green-500"
                          : event.relevanceScore >= 80
                            ? "bg-blue-500"
                            : "bg-yellow-500"
                      }`}
                    >
                      {event.relevanceScore}% Match
                    </Badge>
                  </div>
                </div>

                <CardContent className="p-4">
                  <h3 className="font-bold text-lg mb-1">{event.title}</h3>
                  <div className="space-y-2 mb-3">
                    <div className="flex items-center text-sm">
                      <Calendar className="h-4 w-4 mr-2 text-primary" />
                      <span>{event.date}</span>
                    </div>
                    <div className="flex items-center text-sm">
                      <MapPin className="h-4 w-4 mr-2 text-primary" />
                      <span>{event.location}</span>
                    </div>
                    <div className="flex items-center text-sm">
                      <Users className="h-4 w-4 mr-2 text-primary" />
                      <span>{event.attendees} attendees</span>
                    </div>
                  </div>

                  <p className="text-sm text-muted-foreground mb-3">{event.description}</p>

                  <div className="flex flex-wrap gap-1 mb-4">
                    {event.tags.map((tag, index) => (
                      <Badge key={index} variant="outline" className="bg-primary/5 text-primary">
                        {tag}
                      </Badge>
                    ))}
                  </div>

                  <div className="pt-2 border-t">
                    <div className="flex items-center justify-between">
                      <div className="text-sm">
                        <span className="font-medium">{event.potentialConnections}</span>
                        <span className="text-muted-foreground"> potential connections</span>
                      </div>
                      <Button size="sm">
                        RSVP
                        <ArrowRight className="ml-2 h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          <Card className="border-dashed">
            <CardContent className="pt-6 pb-6 text-center">
              <div className="mx-auto w-12 h-12 rounded-full bg-muted flex items-center justify-center mb-4">
                <Sparkles className="h-6 w-6 text-muted-foreground" />
              </div>
              <h3 className="font-medium mb-2">Looking for more events?</h3>
              <p className="text-sm text-muted-foreground mb-4">
                We can find events tailored to your specific networking goals
              </p>
              <Button>Customize Event Recommendations</Button>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}

