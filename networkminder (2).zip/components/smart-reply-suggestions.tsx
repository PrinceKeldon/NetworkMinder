"use client"

import { useState, useEffect } from "react"
import { Sparkles } from "lucide-react"
import { Button } from "@/components/ui/button"

interface SmartReplySuggestionsProps {
  lastMessage: string
  onSelectReply: (reply: string) => void
}

export function SmartReplySuggestions({ lastMessage, onSelectReply }: SmartReplySuggestionsProps) {
  const [suggestions, setSuggestions] = useState<string[]>([])
  const [isLoading, setIsLoading] = useState(false)

  useEffect(() => {
    if (!lastMessage) return

    setIsLoading(true)

    // Simulate AI generating suggestions
    setTimeout(() => {
      // Generate contextual replies based on the last message
      let contextualReplies: string[] = []

      if (lastMessage.toLowerCase().includes("meeting")) {
        contextualReplies = [
          "I'm available for a meeting next week. What times work for you?",
          "Let's schedule it. I'll send you my calendar link.",
          "I'd love to meet up. Coffee or lunch?",
        ]
      } else if (lastMessage.toLowerCase().includes("project")) {
        contextualReplies = [
          "The project sounds interesting. I'd like to hear more details.",
          "I have some experience in that area. Happy to share insights.",
          "Let's discuss how I might be able to contribute.",
        ]
      } else if (lastMessage.toLowerCase().includes("thanks") || lastMessage.toLowerCase().includes("thank you")) {
        contextualReplies = [
          "You're welcome! Happy to help.",
          "Anytime! Let me know if you need anything else.",
          "No problem at all. Looking forward to our next conversation.",
        ]
      } else {
        // Default replies for other messages
        contextualReplies = [
          "Thanks for reaching out. Let's connect soon.",
          "Great to hear from you. How have you been?",
          "I appreciate the update. Let's catch up this week.",
        ]
      }

      setSuggestions(contextualReplies)
      setIsLoading(false)
    }, 800)
  }, [lastMessage])

  if (!lastMessage || suggestions.length === 0) return null

  return (
    <div className="py-2 space-y-2">
      <div className="flex items-center">
        <Sparkles className="h-3 w-3 text-highlight mr-1" />
        <span className="text-xs text-muted-foreground">AI-suggested replies</span>
      </div>
      <div className="flex flex-wrap gap-2">
        {isLoading ? (
          <div className="w-full text-center py-1">
            <span className="text-xs text-muted-foreground">Generating suggestions...</span>
          </div>
        ) : (
          suggestions.map((suggestion, index) => (
            <Button
              key={index}
              variant="outline"
              size="sm"
              className="text-xs border-primary/20 bg-primary/5 hover:bg-primary/10"
              onClick={() => onSelectReply(suggestion)}
            >
              {suggestion}
            </Button>
          ))
        )}
      </div>
    </div>
  )
}

