"use client"

import { useState, useEffect } from "react"
import { motion } from "framer-motion"
import { Users, Zap, Share2, BarChart } from "lucide-react"
import { Button } from "@/components/ui/button"

interface WelcomeScreenProps {
  onComplete: () => void
}

export function WelcomeScreen({ onComplete }: WelcomeScreenProps) {
  const [progress, setProgress] = useState(0)

  useEffect(() => {
    // Auto-transition after 4 seconds
    const timer = setTimeout(() => {
      onComplete()
    }, 4000)

    // Progress bar animation
    const interval = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          clearInterval(interval)
          return 100
        }
        return prev + 1
      })
    }, 40) // 100 steps over 4 seconds

    return () => {
      clearTimeout(timer)
      clearInterval(interval)
    }
  }, [onComplete])

  return (
    <motion.div
      className="fixed inset-0 z-50 flex flex-col items-center justify-center"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.5 }}
    >
      {/* Colorful background with gradient */}
      <div className="absolute inset-0 bg-gradient-to-br from-primary via-highlight to-primary/70" />

      <div className="relative z-10 flex flex-col items-center justify-center text-white p-6 max-w-md text-center">
        <motion.div
          initial={{ scale: 0.8, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ delay: 0.2, duration: 0.5 }}
          className="mb-6"
        >
          <div className="flex items-center justify-center mb-2">
            <Users className="h-12 w-12 mr-2" />
            <h1 className="text-5xl font-bold tracking-tight">NetworkMinder</h1>
          </div>
          <motion.p
            className="text-xl mt-4 text-white/90"
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.5, duration: 0.5 }}
          >
            Your AI-powered networking assistant
          </motion.p>
        </motion.div>

        <motion.div
          className="grid grid-cols-2 gap-4 mb-8 w-full max-w-sm"
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.8, duration: 0.5 }}
        >
          <div className="flex flex-col items-center bg-white/20 backdrop-blur-sm rounded-lg p-3">
            <Zap className="h-8 w-8 mb-2" />
            <span className="text-sm">Smart Insights</span>
          </div>
          <div className="flex flex-col items-center bg-white/20 backdrop-blur-sm rounded-lg p-3">
            <BarChart className="h-8 w-8 mb-2" />
            <span className="text-sm">AI Analytics</span>
          </div>
          <div className="flex flex-col items-center bg-white/20 backdrop-blur-sm rounded-lg p-3">
            <Share2 className="h-8 w-8 mb-2" />
            <span className="text-sm">Easy Sharing</span>
          </div>
          <div className="flex flex-col items-center bg-white/20 backdrop-blur-sm rounded-lg p-3">
            <Users className="h-8 w-8 mb-2" />
            <span className="text-sm">Event Integration</span>
          </div>
        </motion.div>

        <motion.div
          className="w-full max-w-sm"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1, duration: 0.5 }}
        >
          <div className="w-full bg-white/30 rounded-full h-2 mb-4">
            <div className="bg-white h-2 rounded-full" style={{ width: `${progress}%` }} />
          </div>

          <Button variant="secondary" className="w-full bg-white text-primary hover:bg-white/90" onClick={onComplete}>
            Get Started
          </Button>
        </motion.div>
      </div>
    </motion.div>
  )
}

