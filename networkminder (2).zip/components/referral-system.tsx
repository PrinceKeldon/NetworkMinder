"use client"

import { Badge } from "@/components/ui/badge"

import { useState } from "react"
import { Share2, Gift, Award, Copy, Check, Twitter, Facebook, Linkedin } from "lucide-react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Progress } from "@/components/ui/progress"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

export function ReferralSystem() {
  const [copied, setCopied] = useState(false)
  const [activeTab, setActiveTab] = useState("invite")

  // Mock referral data
  const referralCode = "NETWORK25"
  const referralLink = "https://networkminder.app/ref/NETWORK25"
  const referralStats = {
    invited: 8,
    joined: 3,
    target: 10,
    rewards: [
      { level: 3, reward: "1 month free premium", achieved: true },
      { level: 5, reward: "Access to exclusive events", achieved: false },
      { level: 10, reward: "Annual premium membership", achieved: false },
    ],
  }

  const copyToClipboard = () => {
    navigator.clipboard.writeText(referralLink)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  return (
    <Card className="border-primary/20 shadow-sm">
      <CardHeader>
        <CardTitle className="text-lg flex items-center">
          <Gift className="h-5 w-5 mr-2 text-highlight" />
          Refer & Earn Rewards
        </CardTitle>
        <CardDescription>Invite friends and colleagues to grow your network</CardDescription>
      </CardHeader>
      <CardContent className="pb-2">
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="invite">Invite Friends</TabsTrigger>
            <TabsTrigger value="rewards">Your Rewards</TabsTrigger>
          </TabsList>

          <TabsContent value="invite" className="space-y-4 mt-4">
            <div className="space-y-2">
              <label className="text-sm font-medium">Your Referral Link</label>
              <div className="flex space-x-2">
                <Input value={referralLink} readOnly className="font-mono text-sm" />
                <Button variant="outline" size="icon" onClick={copyToClipboard} className="flex-shrink-0">
                  {copied ? <Check className="h-4 w-4 text-green-500" /> : <Copy className="h-4 w-4" />}
                  <span className="sr-only">{copied ? "Copied" : "Copy"}</span>
                </Button>
              </div>
              <p className="text-xs text-muted-foreground">
                Share this link with friends to earn rewards when they join
              </p>
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium">Your Referral Code</label>
              <div className="flex items-center space-x-2">
                <code className="bg-muted px-2 py-1 rounded text-sm font-mono">{referralCode}</code>
                <span className="text-xs text-muted-foreground">Share this code with friends</span>
              </div>
            </div>

            <div className="pt-2">
              <h4 className="text-sm font-medium mb-3">Share via</h4>
              <div className="flex space-x-2">
                <Button variant="outline" size="sm" className="flex-1">
                  <Twitter className="h-4 w-4 mr-2 text-sky-500" />
                  Twitter
                </Button>
                <Button variant="outline" size="sm" className="flex-1">
                  <Linkedin className="h-4 w-4 mr-2 text-blue-600" />
                  LinkedIn
                </Button>
                <Button variant="outline" size="sm" className="flex-1">
                  <Facebook className="h-4 w-4 mr-2 text-blue-700" />
                  Facebook
                </Button>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="rewards" className="space-y-4 mt-4">
            <div className="space-y-2">
              <div className="flex justify-between items-center">
                <h4 className="text-sm font-medium">Referral Progress</h4>
                <span className="text-sm">
                  {referralStats.joined}/{referralStats.target}
                </span>
              </div>
              <Progress value={(referralStats.joined / referralStats.target) * 100} className="h-2" />
              <p className="text-xs text-muted-foreground">
                {referralStats.invited} friends invited, {referralStats.joined} joined
              </p>
            </div>

            <div className="space-y-3">
              <h4 className="text-sm font-medium">Rewards</h4>
              {referralStats.rewards.map((reward, index) => (
                <div
                  key={index}
                  className={`p-3 rounded-md border ${
                    reward.achieved ? "bg-green-500/10 border-green-500/20" : "bg-muted border-muted-foreground/20"
                  }`}
                >
                  <div className="flex justify-between items-center">
                    <div className="flex items-center">
                      <Award
                        className={`h-4 w-4 mr-2 ${reward.achieved ? "text-green-500" : "text-muted-foreground"}`}
                      />
                      <span className={reward.achieved ? "font-medium" : ""}>{reward.reward}</span>
                    </div>
                    <Badge
                      variant="outline"
                      className={
                        reward.achieved
                          ? "bg-green-500/20 border-green-500/30 text-green-700"
                          : "bg-muted-foreground/10"
                      }
                    >
                      {reward.level} referrals
                    </Badge>
                  </div>
                </div>
              ))}
            </div>
          </TabsContent>
        </Tabs>
      </CardContent>
      <CardFooter className="pt-2">
        <Button className="w-full bg-highlight text-highlight-foreground hover:bg-highlight/90">
          <Share2 className="mr-2 h-4 w-4" />
          Invite More Friends
        </Button>
      </CardFooter>
    </Card>
  )
}

