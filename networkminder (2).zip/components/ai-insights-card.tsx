"use client"

import { useState } from "react"
import { LineChart, BarChart, Activity, Zap, ChevronDown, ChevronUp } from "lucide-react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"

interface AIInsightsCardProps {
  contact?: {
    id: number
    name: string
  }
}

export function AIInsightsCard({ contact }: AIInsightsCardProps) {
  const [expanded, setExpanded] = useState(false)

  // Mock data for insights
  const insights = [
    {
      type: "engagement",
      title: "Engagement Score",
      description: contact
        ? `Your engagement with ${contact.name} has increased by 15% in the last month.`
        : "Your overall network engagement has increased by 8% this month.",
      score: 72,
      change: "+15%",
      positive: true,
    },
    {
      type: "suggestion",
      title: "Suggested Action",
      description: contact
        ? `${contact.name} hasn't been contacted in 3 weeks. Consider scheduling a coffee meeting.`
        : "5 contacts haven't been engaged with in over a month. Consider reaching out.",
      priority: "high",
    },
    {
      type: "social",
      title: "Social Media Activity",
      description: contact
        ? `${contact.name} has been active on LinkedIn discussing AI technology.`
        : "12 contacts have changed jobs recently. Opportunity to reconnect.",
      platforms: ["linkedin", "twitter"],
    },
  ]

  const communicationStats = [
    { label: "Messages", value: contact ? 24 : 156, change: "+5", positive: true },
    { label: "Meetings", value: contact ? 3 : 18, change: "+1", positive: true },
    { label: "Avg Response", value: contact ? "2h" : "4h", change: "-30m", positive: true },
  ]

  return (
    <Card className="border-primary/20 shadow-sm">
      <CardHeader className="pb-2">
        <div className="flex justify-between items-start">
          <div>
            <CardTitle className="text-lg flex items-center">
              <Activity className="h-5 w-5 mr-2 text-primary" />
              AI Insights
            </CardTitle>
            <CardDescription>
              {contact ? `Personalized insights for ${contact.name}` : "Analysis of your networking activity"}
            </CardDescription>
          </div>
          <Badge variant="outline" className="bg-primary/10 text-primary border-primary/20">
            <Zap className="h-3 w-3 mr-1 text-highlight" />
            AI Powered
          </Badge>
        </div>
      </CardHeader>
      <CardContent className="pb-2">
        <div className="space-y-4">
          {insights.map((insight, index) => (
            <div key={index} className="space-y-2">
              <div className="flex justify-between items-center">
                <h4 className="font-medium text-sm">{insight.title}</h4>
                {insight.type === "engagement" && (
                  <span className={`text-xs font-medium ${insight.positive ? "text-green-500" : "text-red-500"}`}>
                    {insight.change}
                  </span>
                )}
                {insight.type === "suggestion" && (
                  <Badge
                    variant={insight.priority === "high" ? "default" : "outline"}
                    className={insight.priority === "high" ? "bg-highlight text-highlight-foreground" : ""}
                  >
                    {insight.priority}
                  </Badge>
                )}
              </div>

              {insight.type === "engagement" && (
                <div className="space-y-1">
                  <Progress value={insight.score} className="h-2" />
                  <p className="text-xs text-muted-foreground">{insight.description}</p>
                </div>
              )}

              {insight.type === "suggestion" && <p className="text-sm">{insight.description}</p>}

              {insight.type === "social" && (
                <div className="space-y-1">
                  <div className="flex space-x-1">
                    {insight.platforms.includes("linkedin") && (
                      <Badge variant="outline" className="bg-blue-500/10 text-blue-500 border-blue-500/20">
                        LinkedIn
                      </Badge>
                    )}
                    {insight.platforms.includes("twitter") && (
                      <Badge variant="outline" className="bg-sky-500/10 text-sky-500 border-sky-500/20">
                        Twitter
                      </Badge>
                    )}
                    {insight.platforms.includes("instagram") && (
                      <Badge variant="outline" className="bg-pink-500/10 text-pink-500 border-pink-500/20">
                        Instagram
                      </Badge>
                    )}
                  </div>
                  <p className="text-xs text-muted-foreground">{insight.description}</p>
                </div>
              )}
            </div>
          ))}

          {expanded && (
            <div className="pt-2 border-t">
              <h4 className="font-medium text-sm mb-3">Communication Analytics</h4>
              <div className="grid grid-cols-3 gap-2">
                {communicationStats.map((stat, index) => (
                  <div key={index} className="text-center p-2 bg-muted/50 rounded-md">
                    <div className="text-lg font-semibold">{stat.value}</div>
                    <div className="text-xs text-muted-foreground">{stat.label}</div>
                    <div className={`text-xs font-medium ${stat.positive ? "text-green-500" : "text-red-500"}`}>
                      {stat.change}
                    </div>
                  </div>
                ))}
              </div>

              <div className="grid grid-cols-2 gap-4 mt-4">
                <Button variant="outline" size="sm" className="w-full">
                  <LineChart className="h-4 w-4 mr-2" />
                  Activity Trends
                </Button>
                <Button variant="outline" size="sm" className="w-full">
                  <BarChart className="h-4 w-4 mr-2" />
                  Engagement Report
                </Button>
              </div>
            </div>
          )}
        </div>
      </CardContent>
      <CardFooter className="pt-0">
        <Button variant="ghost" size="sm" className="w-full text-primary" onClick={() => setExpanded(!expanded)}>
          {expanded ? (
            <>
              <ChevronUp className="h-4 w-4 mr-1" />
              Show Less
            </>
          ) : (
            <>
              <ChevronDown className="h-4 w-4 mr-1" />
              Show More Insights
            </>
          )}
        </Button>
      </CardFooter>
    </Card>
  )
}

