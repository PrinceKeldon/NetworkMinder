"use client"

import { useState, useEffect } from "react"
import { X, Gift, Award, Cake, Briefcase } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"

interface SocialEventNotificationProps {
  onClose: () => void
  type?: "birthday" | "job" | "anniversary" | "achievement"
}

export function SocialEventNotification({ onClose, type = "birthday" }: SocialEventNotificationProps) {
  const [isVisible, setIsVisible] = useState(false)
  const [progress, setProgress] = useState(100)

  // Configure notification based on type
  const notificationConfig = {
    birthday: {
      icon: <Cake className="h-5 w-5 mr-2 text-pink-500" />,
      title: "Birthday Reminder",
      message: "Sam Rivera's birthday is tomorrow!",
      action: "Send Wishes",
      color: "pink",
      bgColor: "bg-pink-500/10",
      borderColor: "border-pink-500/20",
      source: "Facebook",
    },
    job: {
      icon: <Briefcase className="h-5 w-5 mr-2 text-blue-600" />,
      title: "Job Update",
      message: "Alex Johnson started a new position at TechCorp Inc.",
      action: "Congratulate",
      color: "blue",
      bgColor: "bg-blue-600/10",
      borderColor: "border-blue-600/20",
      source: "LinkedIn",
    },
    anniversary: {
      icon: <Award className="h-5 w-5 mr-2 text-purple-600" />,
      title: "Work Anniversary",
      message: "Jordan Lee is celebrating 5 years at DesignHub",
      action: "Congratulate",
      color: "purple",
      bgColor: "bg-purple-600/10",
      borderColor: "border-purple-600/20",
      source: "LinkedIn",
    },
    achievement: {
      icon: <Gift className="h-5 w-5 mr-2 text-green-600" />,
      title: "Achievement",
      message: "Taylor Wilson received a promotion to Senior Developer",
      action: "Congratulate",
      color: "green",
      bgColor: "bg-green-600/10",
      borderColor: "border-green-600/20",
      source: "LinkedIn",
    },
  }

  const config = notificationConfig[type]

  useEffect(() => {
    // Fade in
    setIsVisible(true)

    // Start countdown
    const interval = setInterval(() => {
      setProgress((prev) => {
        if (prev <= 0) {
          clearInterval(interval)
          return 0
        }
        return prev - 1
      })
    }, 50) // 100 steps over 5 seconds

    // Auto close after 5 seconds
    const timeout = setTimeout(() => {
      setIsVisible(false)
      setTimeout(onClose, 300) // Allow time for fade out animation
    }, 5000)

    return () => {
      clearInterval(interval)
      clearTimeout(timeout)
    }
  }, [onClose])

  return (
    <div
      className={`fixed bottom-4 right-4 z-50 transition-opacity duration-300 ${
        isVisible ? "opacity-100" : "opacity-0"
      }`}
    >
      <Card className={`w-80 overflow-hidden shadow-lg ${config.borderColor} border`}>
        <div className="bg-gradient-to-r from-primary to-highlight h-1" style={{ width: `${progress}%` }} />
        <div className="p-4">
          <div className="flex justify-between items-start mb-2">
            <div className="flex items-center">
              {config.icon}
              <h3 className="font-semibold text-sm">{config.title}</h3>
            </div>
            <Button
              variant="ghost"
              size="sm"
              className="h-6 w-6 p-0"
              onClick={() => {
                setIsVisible(false)
                setTimeout(onClose, 300)
              }}
            >
              <X className="h-4 w-4" />
              <span className="sr-only">Close</span>
            </Button>
          </div>

          <div className="flex gap-3">
            <Avatar className="h-10 w-10">
              <AvatarImage src="/placeholder.svg?height=40&width=40" alt="Contact" />
              <AvatarFallback>CN</AvatarFallback>
            </Avatar>
            <div className="flex-1">
              <p className="text-sm">{config.message}</p>
              <p className="text-xs text-muted-foreground">Via {config.source}</p>
            </div>
          </div>

          <div className="mt-3 flex justify-end">
            <Button
              size="sm"
              className={`${
                type === "birthday"
                  ? "bg-pink-500 hover:bg-pink-600"
                  : type === "job" || type === "anniversary"
                    ? "bg-blue-600 hover:bg-blue-700"
                    : "bg-green-600 hover:bg-green-700"
              } text-white`}
            >
              {config.action}
            </Button>
          </div>
        </div>
      </Card>
    </div>
  )
}

