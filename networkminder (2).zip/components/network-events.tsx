"use client"

import { useState } from "react"
import { Calendar, MapPin, Users, ArrowRight, Plus, Search } from "lucide-react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

// Mock data for networking events
const upcomingEvents = [
  {
    id: 1,
    title: "Tech Innovators Meetup",
    date: "Mar 25, 2025",
    time: "6:00 PM - 9:00 PM",
    location: "Downtown Convention Center",
    attendees: 120,
    contacts: 5,
    image: "/placeholder.svg?height=100&width=200",
    category: "technology",
  },
  {
    id: 2,
    title: "Women in Business Conference",
    date: "Apr 10, 2025",
    time: "9:00 AM - 5:00 PM",
    location: "Grand Hotel & Conference Center",
    attendees: 250,
    contacts: 0,
    image: "/placeholder.svg?height=100&width=200",
    category: "business",
  },
  {
    id: 3,
    title: "Startup Pitch Night",
    date: "Apr 18, 2025",
    time: "7:00 PM - 10:00 PM",
    location: "Innovation Hub",
    attendees: 85,
    contacts: 2,
    image: "/placeholder.svg?height=100&width=200",
    category: "startup",
  },
]

const pastEvents = [
  {
    id: 4,
    title: "Digital Marketing Summit",
    date: "Feb 15, 2025",
    location: "Online (Virtual)",
    attendees: 300,
    contacts: 8,
    image: "/placeholder.svg?height=100&width=200",
    category: "marketing",
  },
  {
    id: 5,
    title: "Industry Networking Mixer",
    date: "Jan 28, 2025",
    location: "Skyline Lounge",
    attendees: 75,
    contacts: 12,
    image: "/placeholder.svg?height=100&width=200",
    category: "networking",
  },
]

// Mock data for contacts at events
const eventContacts = {
  1: [
    { id: 101, name: "Taylor Wilson", role: "CTO, TechVision", image: "/placeholder.svg?height=40&width=40" },
    {
      id: 102,
      name: "Jamie Rivera",
      role: "Product Manager, Innovate Inc",
      image: "/placeholder.svg?height=40&width=40",
    },
  ],
  3: [{ id: 103, name: "Casey Morgan", role: "Founder, StartupBoost", image: "/placeholder.svg?height=40&width=40" }],
  5: [
    {
      id: 104,
      name: "Alex Johnson",
      role: "Marketing Director, MediaCorp",
      image: "/placeholder.svg?height=40&width=40",
    },
    { id: 105, name: "Jordan Lee", role: "UX Designer, DesignHub", image: "/placeholder.svg?height=40&width=40" },
  ],
}

export function NetworkEvents() {
  const [activeTab, setActiveTab] = useState("upcoming")
  const [searchTerm, setSearchTerm] = useState("")
  const [expandedEvent, setExpandedEvent] = useState<number | null>(null)

  const filteredUpcoming = upcomingEvents.filter(
    (event) =>
      event.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      event.location.toLowerCase().includes(searchTerm.toLowerCase()) ||
      event.category.toLowerCase().includes(searchTerm.toLowerCase()),
  )

  const filteredPast = pastEvents.filter(
    (event) =>
      event.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      event.location.toLowerCase().includes(searchTerm.toLowerCase()) ||
      event.category.toLowerCase().includes(searchTerm.toLowerCase()),
  )

  const toggleEventExpansion = (id: number) => {
    setExpandedEvent(expandedEvent === id ? null : id)
  }

  return (
    <Card className="border-primary/20 shadow-sm">
      <CardHeader>
        <div className="flex justify-between items-start">
          <div>
            <CardTitle className="text-lg">Networking Events</CardTitle>
            <CardDescription>Discover events and manage your connections</CardDescription>
          </div>
          <Button size="sm">
            <Plus className="h-4 w-4 mr-1" />
            Add Event
          </Button>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="relative">
          <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search events..."
            className="pl-8"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="upcoming">Upcoming</TabsTrigger>
            <TabsTrigger value="past">Past Events</TabsTrigger>
          </TabsList>

          <TabsContent value="upcoming" className="space-y-4 mt-4">
            {filteredUpcoming.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground">No upcoming events found</div>
            ) : (
              filteredUpcoming.map((event) => (
                <div key={event.id} className="space-y-3">
                  <Card className="overflow-hidden">
                    <div className="relative h-32 w-full">
                      <img
                        src={event.image || "/placeholder.svg"}
                        alt={event.title}
                        className="w-full h-full object-cover"
                      />
                      <div className="absolute top-2 right-2">
                        <Badge className="bg-highlight text-highlight-foreground">{event.category}</Badge>
                      </div>
                    </div>
                    <CardContent className="p-4">
                      <h3 className="font-semibold text-lg">{event.title}</h3>
                      <div className="space-y-2 mt-2">
                        <div className="flex items-center text-sm">
                          <Calendar className="h-4 w-4 mr-2 text-primary" />
                          <span>
                            {event.date}, {event.time}
                          </span>
                        </div>
                        <div className="flex items-center text-sm">
                          <MapPin className="h-4 w-4 mr-2 text-primary" />
                          <span>{event.location}</span>
                        </div>
                        <div className="flex items-center text-sm">
                          <Users className="h-4 w-4 mr-2 text-primary" />
                          <span>{event.attendees} attendees</span>
                          {event.contacts > 0 && (
                            <Badge variant="outline" className="ml-2 bg-primary/10 border-primary/20">
                              {event.contacts} contacts
                            </Badge>
                          )}
                        </div>
                      </div>

                      {expandedEvent === event.id && eventContacts[event.id as keyof typeof eventContacts] && (
                        <div className="mt-4 pt-4 border-t">
                          <h4 className="font-medium text-sm mb-2">Your Contacts at This Event</h4>
                          <div className="space-y-2">
                            {eventContacts[event.id as keyof typeof eventContacts]?.map((contact) => (
                              <div key={contact.id} className="flex items-center p-2 rounded-md bg-muted/50">
                                <Avatar className="h-8 w-8 mr-2">
                                  <AvatarImage src={contact.image} alt={contact.name} />
                                  <AvatarFallback>{contact.name.charAt(0)}</AvatarFallback>
                                </Avatar>
                                <div>
                                  <div className="font-medium text-sm">{contact.name}</div>
                                  <div className="text-xs text-muted-foreground">{contact.role}</div>
                                </div>
                              </div>
                            ))}
                          </div>
                        </div>
                      )}
                    </CardContent>
                    <CardFooter className="px-4 py-3 flex justify-between border-t bg-muted/30">
                      {event.contacts > 0 ? (
                        <Button variant="ghost" size="sm" onClick={() => toggleEventExpansion(event.id)}>
                          {expandedEvent === event.id ? "Hide Contacts" : "View Contacts"}
                        </Button>
                      ) : (
                        <span className="text-sm text-muted-foreground">No contacts yet</span>
                      )}
                      <Button size="sm">
                        Event Details
                        <ArrowRight className="ml-1 h-4 w-4" />
                      </Button>
                    </CardFooter>
                  </Card>
                </div>
              ))
            )}
          </TabsContent>

          <TabsContent value="past" className="space-y-4 mt-4">
            {filteredPast.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground">No past events found</div>
            ) : (
              filteredPast.map((event) => (
                <div key={event.id} className="space-y-3">
                  <Card className="overflow-hidden">
                    <div className="relative h-24 w-full">
                      <img
                        src={event.image || "/placeholder.svg"}
                        alt={event.title}
                        className="w-full h-full object-cover"
                      />
                      <div className="absolute top-2 right-2">
                        <Badge className="bg-primary/20 text-primary">{event.category}</Badge>
                      </div>
                    </div>
                    <CardContent className="p-4">
                      <h3 className="font-semibold text-lg">{event.title}</h3>
                      <div className="space-y-2 mt-2">
                        <div className="flex items-center text-sm">
                          <Calendar className="h-4 w-4 mr-2 text-primary" />
                          <span>{event.date}</span>
                        </div>
                        <div className="flex items-center text-sm">
                          <MapPin className="h-4 w-4 mr-2 text-primary" />
                          <span>{event.location}</span>
                        </div>
                        <div className="flex items-center text-sm">
                          <Users className="h-4 w-4 mr-2 text-primary" />
                          <span>{event.attendees} attendees</span>
                          {event.contacts > 0 && (
                            <Badge variant="outline" className="ml-2 bg-primary/10 border-primary/20">
                              {event.contacts} contacts
                            </Badge>
                          )}
                        </div>
                      </div>

                      {expandedEvent === event.id && eventContacts[event.id as keyof typeof eventContacts] && (
                        <div className="mt-4 pt-4 border-t">
                          <h4 className="font-medium text-sm mb-2">Your Contacts at This Event</h4>
                          <div className="space-y-2">
                            {eventContacts[event.id as keyof typeof eventContacts]?.map((contact) => (
                              <div key={contact.id} className="flex items-center p-2 rounded-md bg-muted/50">
                                <Avatar className="h-8 w-8 mr-2">
                                  <AvatarImage src={contact.image} alt={contact.name} />
                                  <AvatarFallback>{contact.name.charAt(0)}</AvatarFallback>
                                </Avatar>
                                <div>
                                  <div className="font-medium text-sm">{contact.name}</div>
                                  <div className="text-xs text-muted-foreground">{contact.role}</div>
                                </div>
                              </div>
                            ))}
                          </div>
                        </div>
                      )}
                    </CardContent>
                    <CardFooter className="px-4 py-3 flex justify-between border-t bg-muted/30">
                      {event.contacts > 0 ? (
                        <Button variant="ghost" size="sm" onClick={() => toggleEventExpansion(event.id)}>
                          {expandedEvent === event.id ? "Hide Contacts" : "View Contacts"}
                        </Button>
                      ) : (
                        <span className="text-sm text-muted-foreground">No contacts yet</span>
                      )}
                      <Button size="sm">
                        View Summary
                        <ArrowRight className="ml-1 h-4 w-4" />
                      </Button>
                    </CardFooter>
                  </Card>
                </div>
              ))
            )}
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  )
}

