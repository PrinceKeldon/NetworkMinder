"use client"

import type React from "react"

import { useState } from "react"
import { Linkedin, Facebook, Twitter, Copy, Check, Share2 } from "lucide-react"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { useToast } from "@/hooks/use-toast"

interface SocialShareDialogProps {
  trigger?: React.ReactNode
  defaultMessage?: string
  shareUrl?: string
}

export function SocialShareDialog({
  trigger,
  defaultMessage = "Check out NetworkMinder, the AI-powered networking assistant that's helping me manage my professional connections!",
  shareUrl = "https://networkminder.app",
}: SocialShareDialogProps) {
  const { toast } = useToast()
  const [message, setMessage] = useState(defaultMessage)
  const [activeTab, setActiveTab] = useState("linkedin")
  const [copied, setCopied] = useState(false)
  const [isSharing, setIsSharing] = useState(false)

  const handleShare = () => {
    setIsSharing(true)

    // Simulate sharing
    setTimeout(() => {
      setIsSharing(false)
      toast({
        title: "Shared Successfully",
        description: `Your message has been shared on ${
          activeTab === "linkedin" ? "LinkedIn" : activeTab === "facebook" ? "Facebook" : "Twitter"
        }`,
      })
    }, 1500)
  }

  const copyToClipboard = () => {
    navigator.clipboard.writeText(`${message} ${shareUrl}`)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)

    toast({
      title: "Copied to Clipboard",
      description: "Share link and message copied to clipboard",
    })
  }

  return (
    <Dialog>
      <DialogTrigger asChild>
        {trigger || (
          <Button>
            <Share2 className="h-4 w-4 mr-2" />
            Share
          </Button>
        )}
      </DialogTrigger>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Share on Social Media</DialogTitle>
          <DialogDescription>Share your networking achievements or invite others to NetworkMinder</DialogDescription>
        </DialogHeader>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="mt-4">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="linkedin" className="flex items-center">
              <Linkedin className="h-4 w-4 mr-2 text-[#0077B5]" />
              LinkedIn
            </TabsTrigger>
            <TabsTrigger value="facebook" className="flex items-center">
              <Facebook className="h-4 w-4 mr-2 text-[#1877F2]" />
              Facebook
            </TabsTrigger>
            <TabsTrigger value="twitter" className="flex items-center">
              <Twitter className="h-4 w-4 mr-2 text-[#1DA1F2]" />
              Twitter
            </TabsTrigger>
          </TabsList>

          <div className="mt-4 space-y-4">
            <div className="space-y-2">
              <label className="text-sm font-medium">Message</label>
              <Textarea
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                placeholder="Write your message here..."
                rows={4}
              />
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium">Share URL</label>
              <div className="flex space-x-2">
                <Input value={shareUrl} readOnly />
                <Button variant="outline" size="icon" onClick={copyToClipboard} className="flex-shrink-0">
                  {copied ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
                </Button>
              </div>
            </div>

            <TabsContent value="linkedin" className="mt-0 pt-2 border-t">
              <div className="rounded-md bg-[#0077B5]/10 p-3 text-sm">
                <p className="font-medium text-[#0077B5] mb-1">LinkedIn Sharing Tips:</p>
                <ul className="list-disc pl-5 space-y-1 text-muted-foreground">
                  <li>Keep it professional and concise</li>
                  <li>Tag relevant connections</li>
                  <li>Use hashtags like #Networking #ProfessionalDevelopment</li>
                </ul>
              </div>
            </TabsContent>

            <TabsContent value="facebook" className="mt-0 pt-2 border-t">
              <div className="rounded-md bg-[#1877F2]/10 p-3 text-sm">
                <p className="font-medium text-[#1877F2] mb-1">Facebook Sharing Tips:</p>
                <ul className="list-disc pl-5 space-y-1 text-muted-foreground">
                  <li>Share with specific groups for better engagement</li>
                  <li>Add a personal touch to your message</li>
                  <li>Consider adding an image for better visibility</li>
                </ul>
              </div>
            </TabsContent>

            <TabsContent value="twitter" className="mt-0 pt-2 border-t">
              <div className="rounded-md bg-[#1DA1F2]/10 p-3 text-sm">
                <p className="font-medium text-[#1DA1F2] mb-1">Twitter Sharing Tips:</p>
                <ul className="list-disc pl-5 space-y-1 text-muted-foreground">
                  <li>Keep it under 280 characters</li>
                  <li>Use relevant hashtags like #Networking</li>
                  <li>Tag @NetworkMinder for potential retweets</li>
                </ul>
              </div>
            </TabsContent>
          </div>
        </Tabs>

        <DialogFooter className="flex items-center justify-between sm:justify-between">
          <Button variant="outline" onClick={copyToClipboard}>
            {copied ? <Check className="h-4 w-4 mr-2" /> : <Copy className="h-4 w-4 mr-2" />}
            Copy Link
          </Button>
          <Button onClick={handleShare} disabled={isSharing}>
            {isSharing ? "Sharing..." : "Share Now"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}

