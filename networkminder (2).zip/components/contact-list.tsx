"use client"

import { useState } from "react"
import { Search } from "lucide-react"
import { Input } from "@/components/ui/input"
import { useToast } from "@/hooks/use-toast"
import { ContactCard } from "@/components/contact-card"
import { useAppStore } from "@/lib/data"

export default function ContactList() {
  const [searchTerm, setSearchTerm] = useState("")
  const { toast } = useToast()

  const contacts = useAppStore((state) => state.contacts)
  const toggleReminder = useAppStore((state) => state.toggleReminder)

  const filteredContacts = contacts.filter(
    (contact) =>
      contact.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      contact.handle.toLowerCase().includes(searchTerm.toLowerCase()) ||
      contact.notes.toLowerCase().includes(searchTerm.toLowerCase()),
  )

  const handleToggleReminder = (id: number) => {
    toggleReminder(id)

    const contact = contacts.find((c) => c.id === id)

    if (contact) {
      // Show toast notification
      toast({
        title: contact.reminder ? "Reminder set" : "Reminder removed",
        description: contact.reminder
          ? `You'll be reminded to follow up with ${contact.name}`
          : `Reminder for ${contact.name} has been removed`,
        duration: 3000,
      })
    }
  }

  return (
    <div className="space-y-6">
      <div className="relative">
        <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
        <Input
          placeholder="Search contacts..."
          className="pl-8"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
        />
      </div>

      {filteredContacts.length === 0 ? (
        <div className="text-center py-10">
          <p className="text-muted-foreground">No contacts found</p>
        </div>
      ) : (
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {filteredContacts.map((contact) => (
            <ContactCard key={contact.id} contact={contact} onToggleReminder={handleToggleReminder} />
          ))}
        </div>
      )}
    </div>
  )
}

