"use client"

import { useState } from "react"
import { FileText, ChevronDown, ChevronUp, Clock } from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"

interface ConversationSummaryProps {
  contactName: string
}

export function ConversationSummary({ contactName }: ConversationSummaryProps) {
  const [expanded, setExpanded] = useState(false)

  // Mock data for conversation summary
  const summary = {
    lastInteraction: "2 days ago",
    duration: "15 minutes",
    keyPoints: [
      "Discussed potential collaboration on the new AI project",
      "Agreed to share resources and research findings",
      "Mentioned interest in attending the upcoming tech conference",
    ],
    actionItems: ["Send project proposal by Friday", "Schedule follow-up meeting next week"],
    topics: ["AI", "Project Collaboration", "Research"],
  }

  return (
    <Card className="border-primary/20 shadow-sm">
      <CardHeader className="pb-2">
        <CardTitle className="text-md flex items-center">
          <FileText className="h-4 w-4 mr-2 text-primary" />
          AI Conversation Summary
        </CardTitle>
      </CardHeader>
      <CardContent className="pt-0">
        <div className="flex items-center text-sm mb-2">
          <Clock className="h-4 w-4 mr-1 text-muted-foreground" />
          <span className="text-muted-foreground">
            Last conversation: {summary.lastInteraction} ({summary.duration})
          </span>
        </div>

        <div className="space-y-3">
          <div>
            <h4 className="text-sm font-medium mb-1">Key Points</h4>
            <ul className="text-sm space-y-1 list-disc pl-5">
              {summary.keyPoints.map((point, index) => (
                <li key={index}>{point}</li>
              ))}
            </ul>
          </div>

          {expanded && (
            <>
              <div>
                <h4 className="text-sm font-medium mb-1">Action Items</h4>
                <ul className="text-sm space-y-1 list-disc pl-5">
                  {summary.actionItems.map((item, index) => (
                    <li key={index}>{item}</li>
                  ))}
                </ul>
              </div>

              <div>
                <h4 className="text-sm font-medium mb-1">Topics Discussed</h4>
                <div className="flex flex-wrap gap-1">
                  {summary.topics.map((topic, index) => (
                    <Badge key={index} variant="outline" className="bg-primary/5 border-primary/20">
                      {topic}
                    </Badge>
                  ))}
                </div>
              </div>
            </>
          )}

          <Button variant="ghost" size="sm" className="w-full text-primary" onClick={() => setExpanded(!expanded)}>
            {expanded ? (
              <>
                <ChevronUp className="h-4 w-4 mr-1" />
                Show Less
              </>
            ) : (
              <>
                <ChevronDown className="h-4 w-4 mr-1" />
                Show More Details
              </>
            )}
          </Button>
        </div>
      </CardContent>
    </Card>
  )
}

