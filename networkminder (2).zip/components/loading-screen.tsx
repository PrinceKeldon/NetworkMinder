"use client"

import { useState, useEffect } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { Users, Zap, Share2, BarChart } from "lucide-react"
import { useRouter } from "next/navigation"

interface LoadingScreenProps {
  onComplete?: () => void
  duration?: number
}

export function LoadingScreen({ onComplete, duration = 3000 }: LoadingScreenProps) {
  const [progress, setProgress] = useState(0)
  const [showLogo, setShowLogo] = useState(true)
  const [showFeatures, setShowFeatures] = useState(false)
  const router = useRouter()

  useEffect(() => {
    // Show logo animation first
    const logoTimer = setTimeout(() => {
      setShowFeatures(true)
    }, 1000)

    // Progress bar animation
    const interval = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          clearInterval(interval)
          return 100
        }
        return prev + 100 / (duration / 100)
      })
    }, 100)

    // Auto-transition after duration
    const transitionTimer = setTimeout(() => {
      setShowLogo(false)
      if (onComplete) {
        onComplete()
      }
    }, duration)

    return () => {
      clearTimeout(logoTimer)
      clearInterval(interval)
      clearTimeout(transitionTimer)
    }
  }, [duration, onComplete])

  return (
    <AnimatePresence mode="wait">
      {showLogo && (
        <motion.div
          className="fixed inset-0 z-50 flex flex-col items-center justify-center bg-background"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.5 }}
        >
          {/* Logo and branding */}
          <motion.div
            initial={{ scale: 0.8, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ delay: 0.2, duration: 0.5 }}
            className="mb-8 relative"
          >
            <div className="relative h-24 w-24 rounded-full bg-primary/10 flex items-center justify-center">
              <div className="absolute inset-0 rounded-full bg-gradient-to-br from-primary via-highlight to-primary/70 opacity-30 animate-pulse" />
              <Users className="h-12 w-12 text-primary" />
            </div>
            <motion.div
              initial={{ y: 20, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ delay: 0.5, duration: 0.5 }}
              className="mt-4 text-center"
            >
              <h1 className="text-3xl font-bold">NetworkMinder</h1>
              <p className="text-sm text-muted-foreground mt-1">Your AI-powered networking assistant</p>
            </motion.div>
          </motion.div>

          {/* Feature icons that appear after initial animation */}
          {showFeatures && (
            <motion.div
              className="grid grid-cols-2 gap-4 mb-8 w-full max-w-xs"
              initial={{ y: 20, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ delay: 0.2, duration: 0.5 }}
            >
              <motion.div
                className="flex flex-col items-center bg-primary/10 backdrop-blur-sm rounded-lg p-3"
                initial={{ scale: 0.8, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                transition={{ delay: 0.3, duration: 0.3 }}
              >
                <Zap className="h-8 w-8 mb-2 text-primary" />
                <span className="text-sm">Smart Insights</span>
              </motion.div>
              <motion.div
                className="flex flex-col items-center bg-primary/10 backdrop-blur-sm rounded-lg p-3"
                initial={{ scale: 0.8, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                transition={{ delay: 0.4, duration: 0.3 }}
              >
                <BarChart className="h-8 w-8 mb-2 text-primary" />
                <span className="text-sm">AI Analytics</span>
              </motion.div>
              <motion.div
                className="flex flex-col items-center bg-primary/10 backdrop-blur-sm rounded-lg p-3"
                initial={{ scale: 0.8, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                transition={{ delay: 0.5, duration: 0.3 }}
              >
                <Share2 className="h-8 w-8 mb-2 text-primary" />
                <span className="text-sm">Easy Sharing</span>
              </motion.div>
              <motion.div
                className="flex flex-col items-center bg-primary/10 backdrop-blur-sm rounded-lg p-3"
                initial={{ scale: 0.8, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                transition={{ delay: 0.6, duration: 0.3 }}
              >
                <Users className="h-8 w-8 mb-2 text-primary" />
                <span className="text-sm">Event Integration</span>
              </motion.div>
            </motion.div>
          )}

          {/* Progress bar */}
          <motion.div
            className="w-full max-w-xs"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.8, duration: 0.5 }}
          >
            <div className="w-full bg-muted rounded-full h-2 mb-4">
              <div
                className="bg-primary h-2 rounded-full transition-all duration-300 ease-out"
                style={{ width: `${progress}%` }}
              />
            </div>
            <p className="text-xs text-center text-muted-foreground">
              {progress < 100 ? "Loading your network..." : "Ready!"}
            </p>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  )
}

