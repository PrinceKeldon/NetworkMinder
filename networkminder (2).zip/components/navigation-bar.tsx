"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { usePathname, useRouter } from "next/navigation"
import { Home, ArrowLeft, BarChart, MessageCircle, Settings, Award, Zap, Menu } from "lucide-react"
import { Button } from "@/components/ui/button"
import { ThemeToggle } from "@/components/theme-toggle"
import { NotificationBell } from "@/components/notification-bell"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"
import { useAppStore } from "@/lib/data"

export function NavigationBar() {
  const pathname = usePathname()
  const router = useRouter()
  const [prevPaths, setPrevPaths] = useState<string[]>([])
  const notifications = useAppStore((state) => state.notifications)
  const unreadCount = notifications.filter((n) => !n.read).length
  const [isScrolled, setIsScrolled] = useState(false)

  // Track navigation history for back button
  useEffect(() => {
    if (pathname && !prevPaths.includes(pathname)) {
      setPrevPaths((prev) => [...prev, pathname])
    }
  }, [pathname])

  // Track scroll position for header styling
  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 10)
    }

    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [])

  const handleBack = () => {
    // Go back to the previous path, skipping loading pages
    if (prevPaths.length > 1) {
      const newPaths = [...prevPaths]
      newPaths.pop() // Remove current path
      const prevPath = newPaths.pop() // Get previous path
      setPrevPaths(newPaths)

      if (prevPath) {
        router.push(prevPath)
      } else {
        router.push("/")
      }
    } else {
      router.push("/")
    }
  }

  // Determine if we should show the back button
  const showBackButton = pathname !== "/" && pathname !== "/landing-page"

  // Determine if we're on a page that should show the full header
  const showFullHeader =
    !pathname.includes("/chat") && !pathname.includes("/contact/") && !pathname.includes("/add-contact")

  return (
    <header
      className={`sticky top-0 z-10 border-b pt-safe transition-all ${
        isScrolled ? "bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60" : "bg-background"
      }`}
    >
      <div className="container flex h-14 items-center">
        <div className="mr-4 flex">
          {showBackButton ? (
            <Button variant="ghost" onClick={handleBack} className="active:scale-95 transition-transform">
              <ArrowLeft className="h-5 w-5" />
              <span className="sr-only">Back</span>
            </Button>
          ) : (
            <Link href="/" className="flex items-center space-x-2">
              <span className="font-bold text-xl">NetworkMinder</span>
            </Link>
          )}

          {/* Home button - always visible */}
          <Link href="/">
            <Button variant="ghost" size="icon" className="ml-2 active:scale-95 transition-transform">
              <Home className="h-5 w-5" />
              <span className="sr-only">Home</span>
            </Button>
          </Link>
        </div>

        {/* Show title on pages with back button */}
        {showBackButton && !showFullHeader && (
          <div className="flex-1 text-center">
            <h1 className="font-semibold">
              {pathname.includes("/chat")
                ? "Messages"
                : pathname.includes("/contact/")
                  ? "Contact Details"
                  : pathname.includes("/add-contact")
                    ? "Add Contact"
                    : ""}
            </h1>
          </div>
        )}

        <div className="flex flex-1 items-center justify-end space-x-2">
          {showFullHeader && (
            <>
              <Link href="/insights" className="hidden md:block">
                <Button variant="ghost" size="icon" className="relative active:scale-95 transition-transform">
                  <BarChart className="h-5 w-5" />
                  <span className="sr-only">Insights</span>
                </Button>
              </Link>
              <Link href="/insights/achievements" className="hidden md:block">
                <Button variant="ghost" size="icon" className="relative active:scale-95 transition-transform">
                  <Award className="h-5 w-5" />
                  <span className="sr-only">Achievements</span>
                </Button>
              </Link>
              <Link href="/chat">
                <Button variant="ghost" size="icon" className="active:scale-95 transition-transform">
                  <MessageCircle className="h-5 w-5" />
                  <span className="sr-only">Chat</span>
                </Button>
              </Link>
              <Link href="/settings/social" className="hidden md:block">
                <Button variant="ghost" size="icon" className="active:scale-95 transition-transform">
                  <Settings className="h-5 w-5" />
                  <span className="sr-only">Settings</span>
                </Button>
              </Link>
            </>
          )}

          <NotificationBell />
          <ThemeToggle />

          {/* Mobile menu */}
          <div className="md:hidden">
            <Sheet>
              <SheetTrigger asChild>
                <Button variant="ghost" size="icon" className="active:scale-95 transition-transform">
                  <Menu className="h-5 w-5" />
                  <span className="sr-only">Menu</span>
                </Button>
              </SheetTrigger>
              <SheetContent side="right" className="w-[250px] sm:w-[300px] pt-safe">
                <div className="flex flex-col h-full">
                  <div className="flex justify-between items-center py-4">
                    <span className="font-bold text-lg">Menu</span>
                  </div>
                  <nav className="flex flex-col space-y-4">
                    <Link
                      href="/"
                      className="flex items-center space-x-2 p-2 rounded-md hover:bg-muted active:bg-muted/80"
                    >
                      <Home className="h-5 w-5" />
                      <span>Home</span>
                    </Link>
                    <Link
                      href="/insights"
                      className="flex items-center space-x-2 p-2 rounded-md hover:bg-muted active:bg-muted/80"
                    >
                      <BarChart className="h-5 w-5" />
                      <span>Insights</span>
                    </Link>
                    <Link
                      href="/insights/achievements"
                      className="flex items-center space-x-2 p-2 rounded-md hover:bg-muted active:bg-muted/80"
                    >
                      <Award className="h-5 w-5" />
                      <span>Achievements</span>
                    </Link>
                    <Link
                      href="/chat"
                      className="flex items-center space-x-2 p-2 rounded-md hover:bg-muted active:bg-muted/80"
                    >
                      <MessageCircle className="h-5 w-5" />
                      <span>Messages</span>
                    </Link>
                    <Link
                      href="/insights/recommendations"
                      className="flex items-center space-x-2 p-2 rounded-md hover:bg-muted active:bg-muted/80"
                    >
                      <Zap className="h-5 w-5" />
                      <span>Recommendations</span>
                    </Link>
                    <Link
                      href="/settings/social"
                      className="flex items-center space-x-2 p-2 rounded-md hover:bg-muted active:bg-muted/80"
                    >
                      <Settings className="h-5 w-5" />
                      <span>Settings</span>
                    </Link>
                  </nav>
                  <div className="mt-auto pt-4 border-t">
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-muted-foreground">© 2025 NetworkMinder</span>
                      <ThemeToggle />
                    </div>
                  </div>
                </div>
              </SheetContent>
            </Sheet>
          </div>
        </div>
      </div>
    </header>
  )
}

