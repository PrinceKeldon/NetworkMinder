"use client"

import { useState } from "react"
import { Bell } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { useToast } from "@/hooks/use-toast"
import { useAppStore } from "@/lib/data"

export function NotificationBell() {
  const [open, setOpen] = useState(false)
  const { toast } = useToast()

  const notifications = useAppStore((state) => state.notifications)
  const markNotificationAsRead = useAppStore((state) => state.markNotificationAsRead)
  const markAllNotificationsAsRead = useAppStore((state) => state.markAllNotificationsAsRead)

  const unreadCount = notifications.filter((n) => !n.read).length

  const markAllAsRead = () => {
    markAllNotificationsAsRead()
  }

  const markAsRead = (id: number) => {
    markNotificationAsRead(id)
  }

  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <Button variant="ghost" size="icon" className="relative">
          <Bell className="h-5 w-5" />
          {unreadCount > 0 && (
            <span className="absolute top-1 right-1 flex h-4 w-4 items-center justify-center rounded-full bg-highlight text-xs font-bold text-highlight-foreground">
              {unreadCount}
            </span>
          )}
          <span className="sr-only">Notifications</span>
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-80 p-0" align="end">
        <div className="flex items-center justify-between p-4 border-b">
          <h3 className="font-medium">Notifications</h3>
          {unreadCount > 0 && (
            <Button variant="ghost" size="sm" onClick={markAllAsRead}>
              Mark all as read
            </Button>
          )}
        </div>
        {notifications.length === 0 ? (
          <div className="p-4 text-center text-muted-foreground">No notifications</div>
        ) : (
          <ScrollArea className="h-[300px]">
            <div className="divide-y">
              {notifications.map((notification) => (
                <div
                  key={notification.id}
                  className={`p-4 ${notification.read ? "" : "bg-primary/5"}`}
                  onClick={() => markAsRead(notification.id)}
                >
                  <div className="flex gap-4">
                    <Avatar className="h-10 w-10">
                      <AvatarImage src={notification.user.image} alt={notification.user.name} />
                      <AvatarFallback>{notification.user.name.charAt(0)}</AvatarFallback>
                    </Avatar>
                    <div className="flex-1 space-y-1">
                      <p className="text-sm">
                        <span className="font-medium">{notification.user.name}</span> {notification.content}
                      </p>
                      <p className="text-xs text-muted-foreground">{notification.time}</p>
                    </div>
                  </div>
                  {notification.type === "instagram_tag" && notification.postImage && (
                    <div className="mt-2 ml-14">
                      <div className="relative h-20 w-20 rounded-md overflow-hidden border">
                        <img
                          src={notification.postImage || "/placeholder.svg"}
                          alt="Instagram post"
                          className="object-cover w-full h-full"
                        />
                      </div>
                    </div>
                  )}
                </div>
              ))}
            </div>
          </ScrollArea>
        )}
      </PopoverContent>
    </Popover>
  )
}

