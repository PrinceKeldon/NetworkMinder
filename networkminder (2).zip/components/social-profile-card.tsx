"use client"

import { useState } from "react"
import { Linkedin, Facebook, ExternalLink, MessageSquare } from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

interface SocialProfileCardProps {
  contact?: {
    id: number
    name: string
  }
  linkedInProfile?: {
    url: string
    title: string
    company: string
    location: string
    connections: number
    mutualConnections: number
  }
  facebookProfile?: {
    url: string
    birthday: string
    location: string
    interests: string[]
    mutualFriends: number
  }
}

export function SocialProfileCard({ contact, linkedInProfile, facebookProfile }: SocialProfileCardProps) {
  const [activeTab, setActiveTab] = useState(linkedInProfile ? "linkedin" : "facebook")

  // Mock data if not provided
  const linkedIn = linkedInProfile || {
    url: "https://linkedin.com/in/alexjohnson",
    title: "Senior Product Manager",
    company: "TechCorp Inc.",
    location: "San Francisco, CA",
    connections: 500,
    mutualConnections: 15,
  }

  const facebook = facebookProfile || {
    url: "https://facebook.com/alexjohnson",
    birthday: "May 15",
    location: "San Francisco, CA",
    interests: ["Technology", "Travel", "Photography"],
    mutualFriends: 8,
  }

  const contactName = contact?.name || "Alex Johnson"

  return (
    <Card className="border-primary/20 shadow-sm">
      <CardHeader className="pb-2">
        <CardTitle className="text-lg">Social Profiles</CardTitle>
      </CardHeader>
      <CardContent className="pt-0">
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="linkedin" className="flex items-center">
              <Linkedin className="h-4 w-4 mr-2 text-[#0077B5]" />
              LinkedIn
            </TabsTrigger>
            <TabsTrigger value="facebook" className="flex items-center">
              <Facebook className="h-4 w-4 mr-2 text-[#1877F2]" />
              Facebook
            </TabsTrigger>
          </TabsList>

          <TabsContent value="linkedin" className="mt-4 space-y-4">
            <div className="space-y-3">
              <div className="flex justify-between items-start">
                <div>
                  <h3 className="font-medium">{linkedIn.title}</h3>
                  <p className="text-sm text-muted-foreground">{linkedIn.company}</p>
                </div>
                <Badge variant="outline" className="bg-[#0077B5]/10 border-[#0077B5]/20 text-[#0077B5]">
                  {linkedIn.connections}+ connections
                </Badge>
              </div>

              <div className="space-y-1">
                <div className="text-sm">
                  <span className="text-muted-foreground">Location:</span> {linkedIn.location}
                </div>
                <div className="text-sm">
                  <span className="text-muted-foreground">Mutual Connections:</span> {linkedIn.mutualConnections}
                </div>
              </div>

              <div className="flex space-x-2 pt-2">
                <Button size="sm" className="flex-1 bg-[#0077B5] hover:bg-[#0077B5]/90">
                  <MessageSquare className="h-4 w-4 mr-2" />
                  Message
                </Button>
                <Button size="sm" variant="outline" className="flex-1">
                  <ExternalLink className="h-4 w-4 mr-2" />
                  View Profile
                </Button>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="facebook" className="mt-4 space-y-4">
            <div className="space-y-3">
              <div className="flex justify-between items-start">
                <div>
                  <h3 className="font-medium">{contactName}</h3>
                  <p className="text-sm text-muted-foreground">{facebook.location}</p>
                </div>
                <Badge variant="outline" className="bg-[#1877F2]/10 border-[#1877F2]/20 text-[#1877F2]">
                  {facebook.mutualFriends} mutual friends
                </Badge>
              </div>

              <div className="space-y-1">
                <div className="text-sm">
                  <span className="text-muted-foreground">Birthday:</span> {facebook.birthday}
                </div>
                <div className="text-sm">
                  <span className="text-muted-foreground">Interests:</span> {facebook.interests.join(", ")}
                </div>
              </div>

              <div className="flex space-x-2 pt-2">
                <Button size="sm" className="flex-1 bg-[#1877F2] hover:bg-[#1877F2]/90">
                  <MessageSquare className="h-4 w-4 mr-2" />
                  Message
                </Button>
                <Button size="sm" variant="outline" className="flex-1">
                  <ExternalLink className="h-4 w-4 mr-2" />
                  View Profile
                </Button>
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  )
}

