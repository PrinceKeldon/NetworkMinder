"use client"

import { useState } from "react"
import { CalendarIcon, Clock, MapPin, Check, Loader2 } from "lucide-react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Calendar } from "@/components/ui/calendar"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { cn } from "@/lib/utils"
import { format } from "date-fns"

interface SmartMeetingSchedulerProps {
  contacts?: Array<{
    id: number
    name: string
    image: string
  }>
}

export function SmartMeetingScheduler({ contacts = [] }: SmartMeetingSchedulerProps) {
  const [date, setDate] = useState<Date>()
  const [selectedContacts, setSelectedContacts] = useState<number[]>([])
  const [meetingType, setMeetingType] = useState<string>("")
  const [isGenerating, setIsGenerating] = useState(false)
  const [suggestions, setSuggestions] = useState<any[]>([])

  // Mock contacts if none provided
  const availableContacts =
    contacts.length > 0
      ? contacts
      : [
          { id: 1, name: "Alex Johnson", image: "/placeholder.svg?height=40&width=40" },
          { id: 2, name: "Sam Rivera", image: "/placeholder.svg?height=40&width=40" },
          { id: 3, name: "Jordan Lee", image: "/placeholder.svg?height=40&width=40" },
        ]

  const toggleContact = (id: number) => {
    setSelectedContacts((prev) => (prev.includes(id) ? prev.filter((contactId) => contactId !== id) : [...prev, id]))
  }

  const generateSuggestions = () => {
    if (!date || selectedContacts.length === 0 || !meetingType) return

    setIsGenerating(true)
    setSuggestions([])

    // Simulate AI processing
    setTimeout(() => {
      // Mock AI-generated suggestions
      const mockSuggestions = [
        {
          time: "10:00 AM - 11:00 AM",
          location: "Coffee Bean & Tea Leaf, Downtown",
          confidence: 92,
          reason:
            "All participants are available and the location is convenient for everyone based on their usual locations.",
        },
        {
          time: "2:00 PM - 3:00 PM",
          location: "Virtual Meeting (Zoom)",
          confidence: 85,
          reason: "One participant has another meeting nearby at 3:30 PM. Virtual meeting provides flexibility.",
        },
        {
          time: "12:00 PM - 1:00 PM",
          location: "Bistro Central, Financial District",
          confidence: 78,
          reason:
            "Lunch meeting aligns with everyone's break time. Location has been used successfully for previous meetings.",
        },
      ]

      setSuggestions(mockSuggestions)
      setIsGenerating(false)
    }, 2000)
  }

  return (
    <Card className="border-primary/20 shadow-sm">
      <CardHeader>
        <CardTitle className="text-lg">AI Meeting Scheduler</CardTitle>
        <CardDescription>Let AI find the optimal time and place for your meeting</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-2">
          <label className="text-sm font-medium">Select Contacts</label>
          <div className="flex flex-wrap gap-2">
            {availableContacts.map((contact) => (
              <Badge
                key={contact.id}
                variant={selectedContacts.includes(contact.id) ? "default" : "outline"}
                className={cn(
                  "cursor-pointer",
                  selectedContacts.includes(contact.id) ? "bg-primary text-primary-foreground" : "hover:bg-primary/10",
                )}
                onClick={() => toggleContact(contact.id)}
              >
                <Avatar className="h-4 w-4 mr-1">
                  <AvatarImage src={contact.image} alt={contact.name} />
                  <AvatarFallback>{contact.name.charAt(0)}</AvatarFallback>
                </Avatar>
                {contact.name}
                {selectedContacts.includes(contact.id) && <Check className="h-3 w-3 ml-1" />}
              </Badge>
            ))}
          </div>
        </div>

        <div className="space-y-2">
          <label className="text-sm font-medium">Meeting Type</label>
          <Select value={meetingType} onValueChange={setMeetingType}>
            <SelectTrigger>
              <SelectValue placeholder="Select meeting type" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="coffee">Coffee Chat</SelectItem>
              <SelectItem value="lunch">Lunch Meeting</SelectItem>
              <SelectItem value="virtual">Virtual Meeting</SelectItem>
              <SelectItem value="formal">Formal Meeting</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          <label className="text-sm font-medium">Preferred Date</label>
          <Popover>
            <PopoverTrigger asChild>
              <Button
                variant="outline"
                className={cn("w-full justify-start text-left font-normal", !date && "text-muted-foreground")}
              >
                <CalendarIcon className="mr-2 h-4 w-4" />
                {date ? format(date, "PPP") : "Select a date"}
              </Button>
            </PopoverTrigger>
            <PopoverContent className="w-auto p-0">
              <Calendar mode="single" selected={date} onSelect={setDate} initialFocus />
            </PopoverContent>
          </Popover>
        </div>

        <Button
          className="w-full"
          onClick={generateSuggestions}
          disabled={!date || selectedContacts.length === 0 || !meetingType || isGenerating}
        >
          {isGenerating ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Generating Suggestions...
            </>
          ) : (
            "Generate AI Suggestions"
          )}
        </Button>

        {suggestions.length > 0 && (
          <div className="space-y-3 pt-2">
            <h3 className="font-medium">AI-Recommended Options:</h3>
            {suggestions.map((suggestion, index) => (
              <Card
                key={index}
                className={cn("border", index === 0 ? "border-highlight bg-highlight/5" : "border-muted")}
              >
                <CardContent className="p-3">
                  <div className="flex justify-between items-start mb-2">
                    <div className="space-y-1">
                      <div className="flex items-center">
                        <Clock className="h-4 w-4 mr-1 text-primary" />
                        <span className="font-medium">{suggestion.time}</span>
                      </div>
                      <div className="flex items-center">
                        <MapPin className="h-4 w-4 mr-1 text-primary" />
                        <span>{suggestion.location}</span>
                      </div>
                    </div>
                    <Badge
                      className={cn(
                        "ml-2",
                        suggestion.confidence > 90
                          ? "bg-green-500"
                          : suggestion.confidence > 80
                            ? "bg-highlight"
                            : "bg-orange-500",
                      )}
                    >
                      {suggestion.confidence}% Match
                    </Badge>
                  </div>
                  <p className="text-xs text-muted-foreground">{suggestion.reason}</p>
                  <div className="mt-2 flex justify-end">
                    <Button size="sm" variant={index === 0 ? "default" : "outline"}>
                      {index === 0 ? "Schedule This" : "Select"}
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  )
}

