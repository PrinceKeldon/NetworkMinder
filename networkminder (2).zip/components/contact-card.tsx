"use client"

import Link from "next/link"
import Image from "next/image"
import { Bell, BellOff } from "lucide-react"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import type { Contact } from "@/lib/data"

interface ContactCardProps {
  contact: Contact
  onToggleReminder: (id: number) => void
}

export function ContactCard({ contact, onToggleReminder }: ContactCardProps) {
  return (
    <Card className="overflow-hidden hover:shadow-md transition-shadow duration-200 border-2 border-transparent hover:border-primary/20">
      <div className="p-4">
        <div className="flex items-start gap-4">
          <div className="relative h-20 w-20 rounded-full overflow-hidden border-2 border-highlight">
            <Image src={contact.image || "/placeholder.svg"} alt={contact.name} fill className="object-cover" />
          </div>
          <div className="flex-1">
            <div className="flex justify-between items-start">
              <div>
                <h3 className="font-semibold text-lg">{contact.name}</h3>
                <p className="text-sm text-primary">{contact.handle}</p>
              </div>
              <Button
                variant="ghost"
                size="icon"
                onClick={() => onToggleReminder(contact.id)}
                className={contact.reminder ? "text-highlight" : ""}
              >
                {contact.reminder ? <Bell className="h-4 w-4" /> : <BellOff className="h-4 w-4" />}
                <span className="sr-only">{contact.reminder ? "Remove reminder" : "Set reminder"}</span>
              </Button>
            </div>
            <p className="text-sm mt-2 line-clamp-2">{contact.notes}</p>
            {contact.reminder && (
              <Badge variant="outline" className="mt-2 bg-highlight/10 text-foreground border-highlight/20">
                Follow up: {new Date(contact.reminderDate || "").toLocaleDateString()}
              </Badge>
            )}
          </div>
        </div>
        <div className="mt-4 flex justify-end">
          <Link href={`/contact/${contact.id}`}>
            <Button variant="outline" size="sm" className="hover:bg-primary hover:text-primary-foreground">
              View Details
            </Button>
          </Link>
        </div>
      </div>
    </Card>
  )
}

