"use client"

import { useState } from "react"
import { Calendar, MessageSquare, Coffee, Briefcase, Users, Sparkles, Check, Plus, Edit, Clock } from "lucide-react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { format } from "date-fns"
import { Calendar as CalendarComponent } from "@/components/ui/calendar"
import { cn } from "@/lib/utils"

// Mock data for follow-ups
const followUps = [
  {
    id: 1,
    contact: {
      id: 101,
      name: "Alex Johnson",
      role: "Senior Developer at InnovateTech",
      image: "/placeholder.svg?height=40&width=40",
    },
    dueDate: "2025-03-20",
    context: "business_meeting",
    notes: "Discussed potential collaboration on the new AI project. Follow up about technical requirements.",
    priority: "high",
    completed: false,
    tags: ["Project", "AI", "Collaboration"],
  },
  {
    id: 2,
    contact: {
      id: 102,
      name: "Sam Rivera",
      role: "Marketing Specialist",
      image: "/placeholder.svg?height=40&width=40",
    },
    dueDate: "2025-03-18",
    context: "coffee_chat",
    notes: "Informal discussion about marketing strategies. Sam mentioned interest in content marketing.",
    priority: "medium",
    completed: false,
    tags: ["Marketing", "Content", "Strategy"],
  },
  {
    id: 3,
    contact: {
      id: 103,
      name: "Jordan Lee",
      role: "UX Designer at DesignHub",
      image: "/placeholder.svg?height=40&width=40",
    },
    dueDate: "2025-03-15",
    context: "networking_event",
    notes: "Met at the Design Conference. Interested in collaborating on the app redesign project.",
    priority: "low",
    completed: false,
    tags: ["Design", "UX", "Collaboration"],
  },
  {
    id: 4,
    contact: {
      id: 104,
      name: "Taylor Wilson",
      role: "Product Manager",
      image: "/placeholder.svg?height=40&width=40",
    },
    dueDate: "2025-03-10",
    context: "business_meeting",
    notes: "Quarterly review meeting. Discussed roadmap for Q2.",
    priority: "high",
    completed: true,
    completedDate: "2025-03-10",
    tags: ["Product", "Roadmap", "Planning"],
  },
]

// Context icons and labels
const contextIcons = {
  business_meeting: <Briefcase className="h-4 w-4" />,
  coffee_chat: <Coffee className="h-4 w-4" />,
  networking_event: <Users className="h-4 w-4" />,
  conference: <Users className="h-4 w-4" />,
  call: <MessageSquare className="h-4 w-4" />,
}

const contextLabels = {
  business_meeting: "Business Meeting",
  coffee_chat: "Coffee Chat",
  networking_event: "Networking Event",
  conference: "Conference",
  call: "Call/Video Chat",
}

// Priority styling
const priorityStyles = {
  high: "bg-red-100 text-red-700 dark:bg-red-700/20 dark:text-red-400",
  medium: "bg-yellow-100 text-yellow-700 dark:bg-yellow-700/20 dark:text-yellow-400",
  low: "bg-blue-100 text-blue-700 dark:bg-blue-700/20 dark:text-blue-400",
}

export function ContextualFollowUp() {
  const [activeTab, setActiveTab] = useState("upcoming")
  const [selectedContext, setSelectedContext] = useState<string | null>(null)
  const [date, setDate] = useState<Date>()
  const [showNewFollowUp, setShowNewFollowUp] = useState(false)

  // Filter follow-ups based on tab and context
  const filteredFollowUps = followUps.filter((followUp) => {
    if (activeTab === "upcoming" && followUp.completed) return false
    if (activeTab === "completed" && !followUp.completed) return false
    if (selectedContext && followUp.context !== selectedContext) return false
    return true
  })

  // AI-suggested follow-up templates based on context
  const getFollowUpSuggestions = (context: string) => {
    switch (context) {
      case "business_meeting":
        return [
          "Following up on our discussion about [topic]. I'd like to schedule some time to dive deeper into [specific point].",
          "It was great meeting with you about [project]. I've attached the resources we discussed for your review.",
          "Thank you for your time yesterday. I've considered your feedback on [topic] and would like to propose the following next steps.",
        ]
      case "coffee_chat":
        return [
          "I enjoyed our coffee chat! I wanted to follow up on our conversation about [topic].",
          "It was great getting to know you better over coffee. I'd love to continue our discussion about [topic].",
          "Thanks for taking the time to meet for coffee. I found your insights on [topic] particularly valuable.",
        ]
      case "networking_event":
        return [
          "It was a pleasure meeting you at [event name]. I'd love to continue our conversation about [topic].",
          "I enjoyed connecting with you at [event]. As mentioned, I'd like to introduce you to [name] who specializes in [area].",
          "Great meeting you at the [event] yesterday! I'd love to learn more about your work in [industry/field].",
        ]
      default:
        return [
          "It was great connecting with you. I'd like to follow up on our conversation.",
          "Thank you for your time. I'm reaching out to continue our discussion.",
          "I appreciated our conversation and would like to explore potential collaboration opportunities.",
        ]
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h2 className="text-2xl font-bold">Contextual Follow-Ups</h2>
          <p className="text-muted-foreground">Smart reminders tailored to your networking context</p>
        </div>
        <Button onClick={() => setShowNewFollowUp(true)}>
          <Plus className="h-4 w-4 mr-2" />
          New Follow-Up
        </Button>
      </div>

      {showNewFollowUp && (
        <Card className="border-highlight/30 bg-highlight/5">
          <CardHeader>
            <CardTitle className="text-lg">Create New Follow-Up</CardTitle>
            <CardDescription>Set a contextual reminder to follow up with a contact</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <label className="text-sm font-medium">Select Contact</label>
              <Select>
                <SelectTrigger>
                  <SelectValue placeholder="Choose a contact" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="101">Alex Johnson</SelectItem>
                  <SelectItem value="102">Sam Rivera</SelectItem>
                  <SelectItem value="103">Jordan Lee</SelectItem>
                  <SelectItem value="104">Taylor Wilson</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium">Interaction Context</label>
              <Select>
                <SelectTrigger>
                  <SelectValue placeholder="Select context" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="business_meeting">
                    <div className="flex items-center">
                      <Briefcase className="h-4 w-4 mr-2" />
                      Business Meeting
                    </div>
                  </SelectItem>
                  <SelectItem value="coffee_chat">
                    <div className="flex items-center">
                      <Coffee className="h-4 w-4 mr-2" />
                      Coffee Chat
                    </div>
                  </SelectItem>
                  <SelectItem value="networking_event">
                    <div className="flex items-center">
                      <Users className="h-4 w-4 mr-2" />
                      Networking Event
                    </div>
                  </SelectItem>
                  <SelectItem value="conference">
                    <div className="flex items-center">
                      <Users className="h-4 w-4 mr-2" />
                      Conference
                    </div>
                  </SelectItem>
                  <SelectItem value="call">
                    <div className="flex items-center">
                      <MessageSquare className="h-4 w-4 mr-2" />
                      Call/Video Chat
                    </div>
                  </SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium">Follow-Up Date</label>
              <Popover>
                <PopoverTrigger asChild>
                  <Button
                    variant="outline"
                    className={cn("w-full justify-start text-left font-normal", !date && "text-muted-foreground")}
                  >
                    <Calendar className="mr-2 h-4 w-4" />
                    {date ? format(date, "PPP") : "Select a date"}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0">
                  <CalendarComponent mode="single" selected={date} onSelect={setDate} initialFocus />
                </PopoverContent>
              </Popover>
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium">Priority</label>
              <Select defaultValue="medium">
                <SelectTrigger>
                  <SelectValue placeholder="Select priority" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="high">High Priority</SelectItem>
                  <SelectItem value="medium">Medium Priority</SelectItem>
                  <SelectItem value="low">Low Priority</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium">Notes</label>
              <Textarea placeholder="Add details about the follow-up..." />
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium">Tags</label>
              <div className="flex flex-wrap gap-2 items-center">
                <Badge variant="outline" className="bg-primary/5 text-primary">
                  Project
                  <button className="ml-1 hover:text-primary/80">×</button>
                </Badge>
                <Badge variant="outline" className="bg-primary/5 text-primary">
                  Collaboration
                  <button className="ml-1 hover:text-primary/80">×</button>
                </Badge>
                <Input placeholder="Add tag..." className="w-24 h-7 text-xs" />
              </div>
            </div>
          </CardContent>
          <CardFooter className="flex justify-between border-t pt-4">
            <Button variant="outline" onClick={() => setShowNewFollowUp(false)}>
              Cancel
            </Button>
            <Button>Create Follow-Up</Button>
          </CardFooter>
        </Card>
      )}

      <div className="flex flex-col sm:flex-row gap-4 justify-between">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full sm:w-auto">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="upcoming">Upcoming</TabsTrigger>
            <TabsTrigger value="completed">Completed</TabsTrigger>
          </TabsList>
        </Tabs>

        <div className="flex flex-wrap gap-2">
          <Badge
            variant={selectedContext === null ? "default" : "outline"}
            className="cursor-pointer"
            onClick={() => setSelectedContext(null)}
          >
            All
          </Badge>
          <Badge
            variant={selectedContext === "business_meeting" ? "default" : "outline"}
            className="cursor-pointer"
            onClick={() => setSelectedContext("business_meeting")}
          >
            <Briefcase className="h-3 w-3 mr-1" />
            Business
          </Badge>
          <Badge
            variant={selectedContext === "coffee_chat" ? "default" : "outline"}
            className="cursor-pointer"
            onClick={() => setSelectedContext("coffee_chat")}
          >
            <Coffee className="h-3 w-3 mr-1" />
            Coffee
          </Badge>
          <Badge
            variant={selectedContext === "networking_event" ? "default" : "outline"}
            className="cursor-pointer"
            onClick={() => setSelectedContext("networking_event")}
          >
            <Users className="h-3 w-3 mr-1" />
            Events
          </Badge>
        </div>
      </div>

      <div className="space-y-4">
        {filteredFollowUps.length === 0 ? (
          <Card className="border-dashed">
            <CardContent className="pt-6 pb-6 text-center">
              <div className="mx-auto w-12 h-12 rounded-full bg-muted flex items-center justify-center mb-4">
                <Calendar className="h-6 w-6 text-muted-foreground" />
              </div>
              <h3 className="font-medium mb-2">No follow-ups found</h3>
              <p className="text-sm text-muted-foreground mb-4">
                {activeTab === "upcoming"
                  ? "You don't have any upcoming follow-ups"
                  : "You haven't completed any follow-ups yet"}
                {selectedContext && ` for ${contextLabels[selectedContext as keyof typeof contextLabels]}`}
              </p>
              <Button onClick={() => setShowNewFollowUp(true)}>
                <Plus className="h-4 w-4 mr-2" />
                Create Follow-Up
              </Button>
            </CardContent>
          </Card>
        ) : (
          filteredFollowUps.map((followUp) => (
            <Card key={followUp.id} className={followUp.completed ? "border-muted bg-muted/10" : "border-primary/20"}>
              <div className="p-4 sm:p-6">
                <div className="flex flex-col sm:flex-row gap-4">
                  <div className="sm:w-1/4">
                    <div className="flex items-center gap-3">
                      <Avatar className="h-10 w-10">
                        <AvatarImage src={followUp.contact.image} alt={followUp.contact.name} />
                        <AvatarFallback>{followUp.contact.name.charAt(0)}</AvatarFallback>
                      </Avatar>
                      <div>
                        <h3 className="font-medium">{followUp.contact.name}</h3>
                        <p className="text-xs text-muted-foreground">{followUp.contact.role}</p>
                      </div>
                    </div>

                    <div className="mt-4 space-y-2">
                      <div className="flex items-center gap-2">
                        <Calendar className="h-4 w-4 text-primary" />
                        <span className="text-sm">
                          {followUp.completed
                            ? `Completed: ${new Date(followUp.completedDate || "").toLocaleDateString()}`
                            : `Due: ${new Date(followUp.dueDate).toLocaleDateString()}`}
                        </span>
                      </div>

                      <div className="flex items-center gap-2">
                        {contextIcons[followUp.context as keyof typeof contextIcons]}
                        <span className="text-sm">{contextLabels[followUp.context as keyof typeof contextLabels]}</span>
                      </div>

                      <div>
                        <Badge className={priorityStyles[followUp.priority as keyof typeof priorityStyles]}>
                          {followUp.priority.charAt(0).toUpperCase() + followUp.priority.slice(1)} Priority
                        </Badge>
                      </div>
                    </div>
                  </div>

                  <div className="sm:w-3/4 space-y-4">
                    <div>
                      <h4 className="font-medium text-sm mb-1">Notes</h4>
                      <p className="text-sm text-muted-foreground">{followUp.notes}</p>
                    </div>

                    <div>
                      <h4 className="font-medium text-sm mb-1">Tags</h4>
                      <div className="flex flex-wrap gap-1">
                        {followUp.tags.map((tag, index) => (
                          <Badge key={index} variant="outline" className="bg-primary/5 text-primary">
                            {tag}
                          </Badge>
                        ))}
                      </div>
                    </div>

                    {!followUp.completed && (
                      <div>
                        <h4 className="font-medium text-sm mb-2 flex items-center">
                          <Sparkles className="h-4 w-4 text-highlight mr-1" />
                          AI-Suggested Follow-up Templates
                        </h4>
                        <div className="space-y-2">
                          {getFollowUpSuggestions(followUp.context).map((suggestion, index) => (
                            <div key={index} className="p-2 bg-muted/50 rounded-md text-sm">
                              {suggestion}
                              <div className="flex justify-end mt-1">
                                <Button variant="ghost" size="sm" className="h-6 text-xs">
                                  Use Template
                                </Button>
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}

                    <div className="flex flex-wrap gap-2 pt-2">
                      {followUp.completed ? (
                        <>
                          <Button variant="outline" size="sm">
                            <Calendar className="h-4 w-4 mr-2" />
                            Schedule New Follow-Up
                          </Button>
                          <Button variant="outline" size="sm">
                            <MessageSquare className="h-4 w-4 mr-2" />
                            Send Message
                          </Button>
                        </>
                      ) : (
                        <>
                          <Button variant="default" size="sm">
                            <Check className="h-4 w-4 mr-2" />
                            Mark Complete
                          </Button>
                          <Button variant="outline" size="sm">
                            <MessageSquare className="h-4 w-4 mr-2" />
                            Send Message
                          </Button>
                          <Button variant="outline" size="sm">
                            <Clock className="h-4 w-4 mr-2" />
                            Reschedule
                          </Button>
                          <Button variant="outline" size="sm">
                            <Edit className="h-4 w-4 mr-2" />
                            Edit
                          </Button>
                        </>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            </Card>
          ))
        )}
      </div>
    </div>
  )
}

